# LinOx Alpine MAX v5

This build focuses only on the Alpine Linux runtime.

Fixes:
- Alpine BusyBox `ash` is no longer started with `-i` over a pipe.
- The persistent shell remains alive and accepts repeated commands.
- Alpine `/proc`, `/dev`, `/sys` are exposed through PRoot when available.
- Alpine repositories are repaired if extraction left media-only repositories.
- `/tmp`, `/run`, hostname, PATH, HOME, LANG and profile are normalized.
- A RESTART button is provided if the guest shell is explicitly exited.
- Commands are echoed in the UI so the terminal remains readable.

Important limitation:
The current transport is a persistent stdin/stdout pipe, not a true PTY. This fixes
ordinary shell commands and prevents the current Alpine startup/second-command failure.
Full-screen terminal applications such as nano/vim/top still need a real PTY layer;
they are not falsely claimed to be fixed by this build.
