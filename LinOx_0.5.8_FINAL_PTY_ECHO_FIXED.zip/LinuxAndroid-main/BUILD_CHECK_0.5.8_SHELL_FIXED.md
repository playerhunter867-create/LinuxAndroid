# LinOx 0.5.8 — shell startup fix

This revision keeps the working native PRoot architecture and fixes the remaining
interactive-shell startup path.

Changes:
- Alpine is started explicitly as `/bin/sh -i` instead of `/bin/sh -l`.
- The initial PRoot mount set is minimal: rootfs, `/root`, `/tmp`, and working
  directory `/root`. Android `/dev` and `/proc` are not bound during startup,
  avoiding OEM-specific host mount restrictions.
- The terminal reports a shell startup failure instead of silently presenting
  the generic "shell is not running" message.
- PRoot remains bundled under `jniLibs/arm64-v8a/libproot.so`.
- targetSdk remains 28 for Android 10+ rootless guest execution compatibility.
