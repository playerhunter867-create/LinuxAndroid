# LinOx 0.5.8 — real PTY shell fix

This build replaces the old `ProcessBuilder` pipe-based interactive session with
an Android NDK/JNI PTY implementation.

## What changed

- Creates a real Unix pseudo-terminal (`posix_openpt`/`grantpt`/`unlockpt`).
- Starts PRoot as the PTY child process.
- Creates a session and controlling terminal with `setsid()` + `TIOCSCTTY`.
- Connects the guest shell to PTY stdin/stdout/stderr.
- Sets an initial terminal size of 120x40 and exposes resize support.
- Keeps LinOx's existing Alpine `/bin/sh -i` startup command.
- Adds Android NDK/CMake to the GitHub Actions build so the PTY library is
  compiled into `liblinoxpty.so` for arm64-v8a.

The previous warning about `can't access tty; job control turned off` came from
using Java `ProcessBuilder` pipes for an interactive shell. With this build,
BusyBox `ash` receives an actual controlling TTY.
