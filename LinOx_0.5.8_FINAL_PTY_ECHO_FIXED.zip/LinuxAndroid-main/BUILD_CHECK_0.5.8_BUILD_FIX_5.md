# LinOx 0.5.8 — Android guest exec fix

## Exact failure fixed

The app reached PRoot successfully, but PRoot then failed at:

`proot error: execve("/bin/sh"): Permission denied`

That means the PRoot executable itself was no longer the failing component. The failure happened when PRoot attempted to execute the Linux guest's `/bin/sh` from writable app-private storage.

Android 10 introduced execution restrictions for apps targeting API 29 or higher: an app cannot directly `exec()` native code from its writable app home directory. PRoot can rewrite paths, but it cannot make the kernel ignore that host-side execution restriction.

## Fix used by this build

- `compileSdk = 35` remains unchanged.
- `minSdk = 26` remains unchanged.
- **`targetSdk = 28` is intentional.**
- PRoot remains bundled as `app/src/main/jniLibs/arm64-v8a/libproot.so`.
- PRoot is still launched from Android's `nativeLibraryDir`.
- Linux rootfs remains in private app storage.
- `PROOT_NO_SECCOMP=1` remains enabled for Android kernels where PRoot's seccomp acceleration is blocked.
- The GitHub Actions workflow verifies the target SDK and the AArch64 PRoot before building.

This target-SDK compatibility approach is used by Termux for the Android 10+ app-data execution restriction; see the Termux execution-environment documentation and Android's Android 10 behavior changes documentation.
