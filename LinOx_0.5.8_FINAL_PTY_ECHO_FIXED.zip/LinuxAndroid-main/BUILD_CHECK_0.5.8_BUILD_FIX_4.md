# LinOx 0.5.8 — Build Fix 4

Root cause found in the previous archive: `LinuxRuntime.kt` declared two functions with the exact same Kotlin signature:

- private `isArm64Device()` near PRoot validation
- public `isArm64Device()` near device info

Kotlin rejects duplicate declarations with the same signature, so Gradle never reached APK packaging.

Fix:
- renamed the private validation helper to `isArm64DeviceInternal()`;
- kept the public `isArm64Device()` API unchanged;
- updated the internal PRoot validation call;
- kept the native PRoot/jniLibs architecture changes intact;
- added a GitHub Actions preflight that detects duplicate Kotlin function names before Gradle.

AGP 8.6.x + Gradle 8.7 + JDK 17 + compileSdk 35 remains a supported combination according to Android's compatibility documentation.
