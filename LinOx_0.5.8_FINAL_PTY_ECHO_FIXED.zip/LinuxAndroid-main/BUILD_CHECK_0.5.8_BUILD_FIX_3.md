# LinOx 0.5.8 build fix 3

The previous workflow could fail before the actual APK compile because the runner did not explicitly provision Android API 35/build-tools. This revision keeps the native PRoot architecture intact and adds explicit Android SDK provisioning.

Preserved:
- app/src/main/jniLibs/arm64-v8a/libproot.so
- LinuxRuntime nativeLibraryDir PRoot path
- private app rootfs layout
- existing LinOx Kotlin source

Build changes:
- JDK 17
- Gradle 8.7
- AGP 8.6.1
- Kotlin 1.9.24
- explicit Android platform 35 and build-tools 35.0.0
- Gradle build runs with --stacktrace --info and saves build.log
- final APK is checked for lib/arm64-v8a/libproot.so
