# LinOx 0.5.8 — PTY EIO / terminal initialization fix

This revision fixes the remaining interactive PTY problem where Alpine could
start successfully but the first terminal read later reported:

`[LinOx] read failed: EIO (I/O error)`

Changes:
- PTY window size is initialized before `fork()` and again on the slave.
- The PTY master is explicitly kept in blocking mode.
- The child now requires `setsid()` and `TIOCSCTTY`; it no longer silently
  continues without a controlling terminal.
- Child signal dispositions are reset to normal defaults before PRoot starts.
- Java no longer prints Linux PTY `EIO` as an application error. On Unix,
  `EIO` from a PTY master is the normal EOF indication after the slave closes.
- Command writes no longer perform a racy `isAlive()` check before writing.
- PRoot/Alpine startup remains `/bin/sh -i` with the real controlling PTY.

The bundled PRoot and rootfs architecture is unchanged.
