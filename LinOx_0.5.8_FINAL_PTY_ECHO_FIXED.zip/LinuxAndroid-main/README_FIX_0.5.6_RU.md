# LinOx 0.5.6 — superseded

This file documents the previous 0.5.6 build.

For the current corrected build, see `README_LINOX_0.5.8.md`.

LinOx 0.5.8 additionally fixes the two remaining problems seen in testing:

- Ubuntu/Debian could report installed but fail with the generic PRoot/rootfs error.
- Alpine could report `installed` while the distribution card still showed `PREPARE / DOWNLOAD`.

The new build validates the bundled ARM64 PRoot and explicitly materializes `/bin/sh` when Android storage cannot preserve the distro symlink.
