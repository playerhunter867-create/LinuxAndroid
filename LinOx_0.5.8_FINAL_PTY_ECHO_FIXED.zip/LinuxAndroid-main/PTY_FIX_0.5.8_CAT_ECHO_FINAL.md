# LinOx 0.5.8 — final PTY echo fix

This revision starts each PRoot guest with an explicitly initialized interactive
termios state on the PTY slave. In particular, ECHO, ICANON and ISIG are enabled,
canonical input and output processing are restored, and standard control
characters are configured before PRoot/`/bin/sh` is exec'd.

The previous `TERM=dumb` workaround is removed. Guests receive
`TERM=xterm-256color` again. The existing small device-status query bridge is kept
for the command-oriented Android UI so `ESC[6n` does not become visible text.

Test after rebuilding:

    echo one
    cat /etc/os-release
    echo two
    pwd
    echo three
    ls

Also test Ctrl+C with:

    sleep 30

Expected: after `cat /etc/os-release`, the next command is still echoed and
accepted. `EIO` from normal PTY shutdown remains treated as EOF.
