# LinOx 0.5.8 build fix 2

This build keeps the 0.5.8 native PRoot architecture and changes only build reliability:

- AGP 8.6.1 + Gradle 8.7 + JDK 17 remain aligned with Android's AGP 8.6 compatibility matrix.
- Kotlin is pinned to 1.9.24; the project does not require Kotlin 2.x language features.
- `keepDebugSymbols += "**/libproot.so"` uses the documented JniLibsPackaging API.
- The test instrumentation runner declaration was removed because no Android test dependency is present.
- The workflow verifies the final APK contains `lib/arm64-v8a/libproot.so` and uploads a build log if a future failure occurs.

Runtime architecture is unchanged: PRoot is bundled under `app/src/main/jniLibs/arm64-v8a/` and LinuxRuntime resolves it from `ApplicationInfo.nativeLibraryDir` rather than `files/linox-runtime/`.
