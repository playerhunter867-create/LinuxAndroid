# LinOx 0.5.8 — debug build fix

This archive keeps the LinOx 0.5.8 native-PRoot architecture from the previous build and fixes the GitHub Actions debug-build setup.

## Build configuration
- Android Gradle Plugin: 8.6.1
- Gradle: 8.7
- JDK: 17
- compileSdk/targetSdk: 35
- Native ABI: arm64-v8a only
- PRoot: `app/src/main/jniLibs/arm64-v8a/libproot.so`
- APK task: `:app:clean :app:assembleDebug`

## PRoot runtime architecture
PRoot is **not** copied to `files/linox-runtime/`. LinOx resolves it from `ApplicationInfo.nativeLibraryDir` as `libproot.so`.

The workflow verifies that the bundled file is an ELF64 AArch64 binary and that the resulting APK contains `lib/arm64-v8a/libproot.so`.

## Why this build file was changed
The previous workflow did not explicitly constrain the single native ABI and did not verify the Android SDK/native payload before compilation. This version makes those assumptions explicit and emits the full Gradle stack trace if GitHub Actions encounters a build error.
