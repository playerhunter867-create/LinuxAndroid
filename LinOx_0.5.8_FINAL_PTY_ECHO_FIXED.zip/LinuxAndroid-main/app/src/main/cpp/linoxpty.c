#include <jni.h>
#include <android/log.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/select.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <termios.h>
#include <unistd.h>
#include <stdint.h>
#include <sys/stat.h>

#define LOG_TAG "LinOxPTY"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

static char *jstring_dup(JNIEnv *env, jstring s) {
    if (!s) return NULL;
    const char *p = (*env)->GetStringUTFChars(env, s, NULL);
    if (!p) return NULL;
    char *out = strdup(p);
    (*env)->ReleaseStringUTFChars(env, s, p);
    return out;
}

static char **string_array_dup(JNIEnv *env, jobjectArray arr, int *count) {
    jsize n = arr ? (*env)->GetArrayLength(env, arr) : 0;
    char **out = (char **)calloc((size_t)n + 1, sizeof(char *));
    if (!out) return NULL;
    for (jsize i = 0; i < n; ++i) {
        jstring s = (jstring)(*env)->GetObjectArrayElement(env, arr, i);
        out[i] = jstring_dup(env, s);
        (*env)->DeleteLocalRef(env, s);
        if (!out[i]) {
            for (jsize j = 0; j < i; ++j) free(out[j]);
            free(out);
            return NULL;
        }
    }
    out[n] = NULL;
    if (count) *count = (int)n;
    return out;
}

static void free_string_array(char **arr) {
    if (!arr) return;
    for (char **p = arr; *p; ++p) free(*p);
    free(arr);
}

static void configure_interactive_termios(int fd) {
    struct termios tio;
    if (tcgetattr(fd, &tio) != 0) {
        LOGE("tcgetattr failed: %s", strerror(errno));
        return;
    }

    /*
     * Start every guest with a known interactive terminal state.
     * This is deliberately done in the native PTY layer rather than in
     * Alpine/Debian/Ubuntu startup scripts. A program such as cat must never
     * inherit a stale ECHO/ICANON state from an earlier session.
     */
    tio.c_iflag |= (BRKINT | ICRNL | IXON | IXOFF | IMAXBEL);
    tio.c_iflag &= ~(IGNBRK | INLCR | IGNCR | IXANY | PARMRK);

    tio.c_oflag |= (OPOST | ONLCR);

    tio.c_cflag |= (CREAD | CS8);
    tio.c_cflag &= ~(PARENB | CSTOPB | CSIZE);
    tio.c_cflag |= CS8;

    tio.c_lflag |= (ISIG | ICANON | ECHO | ECHOE | ECHOK | ECHOCTL | IEXTEN);
    tio.c_lflag &= ~(ECHONL | NOFLSH | TOSTOP);

    tio.c_cc[VINTR] = 3;   /* Ctrl-C */
    tio.c_cc[VQUIT] = 28;  /* Ctrl-\\ */
    tio.c_cc[VERASE] = 127;
    tio.c_cc[VKILL] = 21;  /* Ctrl-U */
    tio.c_cc[VEOF] = 4;    /* Ctrl-D */
    tio.c_cc[VSTART] = 17;
    tio.c_cc[VSTOP] = 19;
    tio.c_cc[VSUSP] = 26;  /* Ctrl-Z */
    tio.c_cc[VMIN] = 1;
    tio.c_cc[VTIME] = 0;

    if (tcsetattr(fd, TCSANOW, &tio) != 0) {
        LOGE("tcsetattr failed: %s", strerror(errno));
    }
}

static void set_initial_winsize(int fd) {
    struct winsize ws;
    memset(&ws, 0, sizeof(ws));
    ws.ws_row = 40;
    ws.ws_col = 120;
    ioctl(fd, TIOCSWINSZ, &ws);
}

static jlong pack_handle(pid_t pid, int fd) {
    return (((jlong)(uint32_t)pid) << 32) | (jlong)(uint32_t)fd;
}

static pid_t unpack_pid(jlong handle) {
    return (pid_t)(uint32_t)((uint64_t)handle >> 32);
}

static int unpack_fd(jlong handle) {
    return (int)(uint32_t)((uint64_t)handle & 0xffffffffULL);
}

JNIEXPORT jlong JNICALL
Java_org_linox_mobile_NativePty_nativeStart(JNIEnv *env, jclass clazz,
                                              jstring executable,
                                              jobjectArray args,
                                              jobjectArray environment,
                                              jstring workingDirectory) {
    (void)clazz;
    char *exe = jstring_dup(env, executable);
    char *cwd = jstring_dup(env, workingDirectory);
    int argc = 0, envc = 0;
    char **arg_strings = string_array_dup(env, args, &argc);
    char **env_strings = string_array_dup(env, environment, &envc);
    if (!exe || !arg_strings || !env_strings) {
        free(exe); free(cwd); free_string_array(arg_strings); free_string_array(env_strings);
        return -1;
    }

    char **argv = (char **)calloc((size_t)argc + 2, sizeof(char *));
    if (!argv) {
        free(exe); free(cwd); free_string_array(arg_strings); free_string_array(env_strings);
        return -1;
    }
    argv[0] = exe;
    for (int i = 0; i < argc; ++i) argv[i + 1] = arg_strings[i];
    argv[argc + 1] = NULL;

    int master = posix_openpt(O_RDWR | O_NOCTTY | O_CLOEXEC);
    if (master < 0 || grantpt(master) != 0 || unlockpt(master) != 0) {
        LOGE("posix_openpt/grantpt/unlockpt failed: %s", strerror(errno));
        if (master >= 0) close(master);
        free(argv); free(exe); free(cwd); free_string_array(arg_strings); free_string_array(env_strings);
        return -1;
    }

    char *slave_name = ptsname(master);
    if (!slave_name) {
        LOGE("ptsname failed: %s", strerror(errno));
        close(master);
        free(argv); free(exe); free(cwd); free_string_array(arg_strings); free_string_array(env_strings);
        return -1;
    }

    // Set the initial size before fork so the child can query a valid
    // terminal size immediately during shell/PRoot startup.
    set_initial_winsize(master);

    // Keep the PTY master in blocking mode. Android/bionic can otherwise
    // propagate an inherited non-blocking flag and make Java reads race the
    // PTY lifecycle.
    int master_flags = fcntl(master, F_GETFL, 0);
    if (master_flags >= 0) {
        fcntl(master, F_SETFL, master_flags & ~O_NONBLOCK);
    }

    pid_t pid = fork();
    if (pid < 0) {
        LOGE("fork failed: %s", strerror(errno));
        close(master);
        free(argv); free(exe); free(cwd); free_string_array(arg_strings); free_string_array(env_strings);
        return -1;
    }

    if (pid == 0) {
        int slave = open(slave_name, O_RDWR | O_NOCTTY);
        if (slave < 0) _exit(127);

        // The child must own a session and a controlling terminal. Do not
        // silently continue without it: BusyBox ash/PRoot then falls back to
        // pipe-like behavior and the PTY master can later report EIO.
        if (setsid() < 0) _exit(125);
        if (ioctl(slave, TIOCSCTTY, 0) < 0) _exit(125);

        // Restore normal signal defaults inherited from the Android app.
        signal(SIGPIPE, SIG_DFL);
        signal(SIGINT, SIG_DFL);
        signal(SIGTERM, SIG_DFL);
        signal(SIGHUP, SIG_DFL);
        signal(SIGQUIT, SIG_DFL);

        // Apply the same initial terminal dimensions to the slave before
        // execve(), avoiding a 0x0 window during shell initialization.
        set_initial_winsize(slave);
        configure_interactive_termios(slave);

        dup2(slave, STDIN_FILENO);
        dup2(slave, STDOUT_FILENO);
        dup2(slave, STDERR_FILENO);
        if (slave > STDERR_FILENO) close(slave);
        close(master);

        if (cwd && chdir(cwd) != 0) {
            dprintf(STDERR_FILENO, "LinOx PTY: chdir(%s): %s\n", cwd, strerror(errno));
            _exit(126);
        }

        // The caller supplies the complete environment so the guest receives
        // TERM, HOME, PATH, PRoot variables, etc. exactly as LinOx requested.
        execve(exe, argv, env_strings);
        dprintf(STDERR_FILENO, "LinOx PTY: execve(%s): %s\n", exe, strerror(errno));
        _exit(errno == EACCES ? 126 : 127);
    }

    fcntl(master, F_SETFD, FD_CLOEXEC);

    free(argv);
    free(exe);
    free(cwd);
    // arg_strings/env_strings are still owned by their arrays; argv pointed into
    // arg_strings, but the child has its own address space after fork. Safe here.
    free_string_array(arg_strings);
    free_string_array(env_strings);

    return pack_handle(pid, master);
}

JNIEXPORT void JNICALL
Java_org_linox_mobile_NativePty_nativeStop(JNIEnv *env, jclass clazz, jlong handle) {
    (void)env; (void)clazz;
    if (handle <= 0) return;
    // Java owns the PTY master FD through ParcelFileDescriptor. Do not close it
    // here; closing it twice could close an unrelated descriptor after reuse.
    pid_t pid = unpack_pid(handle);
    if (pid > 0) {
        kill(pid, SIGHUP);
        kill(pid, SIGTERM);
        int status;
        for (int i = 0; i < 10; ++i) {
            pid_t r = waitpid(pid, &status, WNOHANG);
            if (r == pid) return;
            usleep(20000);
        }
        kill(pid, SIGKILL);
        waitpid(pid, &status, 0);
    }
}

JNIEXPORT void JNICALL
Java_org_linox_mobile_NativePty_nativeResize(JNIEnv *env, jclass clazz, jlong handle, jint rows, jint cols) {
    (void)env; (void)clazz;
    if (handle <= 0) return;
    int fd = unpack_fd(handle);
    struct winsize ws;
    memset(&ws, 0, sizeof(ws));
    ws.ws_row = (unsigned short)(rows > 0 ? rows : 40);
    ws.ws_col = (unsigned short)(cols > 0 ? cols : 120);
    ioctl(fd, TIOCSWINSZ, &ws);
}

JNIEXPORT jboolean JNICALL
Java_org_linox_mobile_NativePty_nativeIsAlive(JNIEnv *env, jclass clazz, jlong handle) {
    (void)env; (void)clazz;
    if (handle <= 0) return JNI_FALSE;
    pid_t pid = unpack_pid(handle);
    if (pid <= 0) return JNI_FALSE;
    if (kill(pid, 0) == 0) return JNI_TRUE;
    return errno == EPERM ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jint JNICALL
Java_org_linox_mobile_NativePty_nativeFd(JNIEnv *env, jclass clazz, jlong handle) {
    (void)env; (void)clazz;
    return handle > 0 ? unpack_fd(handle) : -1;
}
