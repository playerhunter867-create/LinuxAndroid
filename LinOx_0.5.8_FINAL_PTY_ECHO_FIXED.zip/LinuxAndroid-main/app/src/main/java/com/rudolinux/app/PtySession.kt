package org.linox.mobile

import android.os.ParcelFileDescriptor
import java.io.InputStream
import java.io.OutputStream
import java.nio.charset.Charset
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Interactive terminal session backed by a real Unix PTY.
 *
 * PRoot and Alpine's BusyBox ash see an actual controlling terminal instead of
 * ProcessBuilder pipes, so job control and interactive shell startup work as
 * they do in a normal Linux terminal.
 */
class PtySession private constructor(
    private val handle: Long,
    private val pfd: ParcelFileDescriptor,
    private val input: InputStream,
    private val output: OutputStream
) {
    private val stopped = AtomicBoolean(false)

    companion object {
        fun start(
            executable: String,
            args: List<String>,
            environment: Map<String, String> = emptyMap(),
            workingDirectory: String? = null
        ): PtySession {
            val env = environment.entries.map { (key, value) -> "$key=$value" }.toTypedArray()
            val handle = NativePty.nativeStart(
                executable,
                args.toTypedArray(),
                env,
                workingDirectory
            )

            if (handle <= 0) {
                error("Unable to create Linux PTY for PRoot")
            }

            val fd = NativePty.nativeFd(handle)
            if (fd < 0) {
                NativePty.nativeStop(handle)
                error("Linux PTY returned an invalid file descriptor")
            }

            val pfd = ParcelFileDescriptor.adoptFd(fd)
            // Duplicate the master FD so closing the Java input/output streams
            // cannot accidentally double-close the descriptor owned by pfd.
            val inputPfd = ParcelFileDescriptor.dup(pfd.fileDescriptor)
            val outputPfd = ParcelFileDescriptor.dup(pfd.fileDescriptor)
            val input = ParcelFileDescriptor.AutoCloseInputStream(inputPfd)
            val output = ParcelFileDescriptor.AutoCloseOutputStream(outputPfd)
            return PtySession(handle, pfd, input, output)
        }
    }

    fun send(command: String) {
        if (stopped.get()) return
        try {
            output.write(command.toByteArray(Charsets.UTF_8))
            output.write('\n'.code)
            output.flush()
        } catch (_: Exception) {
            // The shell may have exited between isAlive() and the write.
        }
    }

    fun sendBytes(bytes: ByteArray) {
        if (stopped.get()) return
        runCatching {
            output.write(bytes)
            output.flush()
        }
    }

    fun readLoop(
        onText: (String) -> Unit,
        onExit: (Int) -> Unit = {}
    ) {
        Thread {
            var exitCode = -1
            try {
                val buffer = ByteArray(8192)
                // The native PTY starts every guest with a clean interactive
                // termios state. The UI is still command-oriented rather than a
                // full VT emulator, so a few device-status queries are answered
                // here instead of being rendered as literal text.
                val pending = StringBuilder()
                while (!stopped.get()) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    if (count > 0) {
                        pending.append(String(buffer, 0, count, Charsets.UTF_8))
                        val text = handleTerminalQueries(pending)
                        if (text.isNotEmpty()) onText(text)
                    }
                }
                if (pending.isNotEmpty()) {
                    onText(pending.toString())
                    pending.setLength(0)
                }
            } catch (e: Exception) {
                if (!stopped.get()) {
                    // On Linux PTYs, read(2) commonly returns EIO when the
                    // slave side closes. That is EOF semantics, not an
                    // application I/O failure. Do not print the raw EIO to
                    // the terminal and make a normal shell exit look broken.
                    val message = e.message ?: e.javaClass.simpleName
                    if (!message.contains("EIO", ignoreCase = true) &&
                        !message.contains("I/O error", ignoreCase = true)
                    ) {
                        onText("\n[LinOx] PTY read failed: $message\n")
                    }
                }
            } finally {
                if (!NativePty.nativeIsAlive(handle)) exitCode = 0
                onExit(exitCode)
            }
        }.apply {
            name = "LinOx-pty-reader"
            isDaemon = true
            start()
        }
    }


    /**
     * Handle the small subset of terminal status queries that can block an
     * interactive guest. The Android TextView is not itself a VT emulator, so
     * these control sequences must be answered here and removed from visible
     * output.
     */
    private fun handleTerminalQueries(buffer: StringBuilder): String {
        val visible = StringBuilder()
        while (true) {
            val start = buffer.indexOf("\u001B[")
            if (start < 0) {
                // Keep a possible incomplete ESC/CSI prefix for the next read.
                if (buffer.isNotEmpty() && buffer.last() == '\u001B') {
                    visible.append(buffer.substring(0, buffer.length - 1))
                    val last = buffer[buffer.length - 1]
                    buffer.setLength(0)
                    buffer.append(last)
                } else {
                    visible.append(buffer)
                    buffer.setLength(0)
                }
                break
            }

            visible.append(buffer.substring(0, start))
            if (buffer.length < start + 3) {
                // Incomplete CSI sequence; wait for the next PTY read.
                val rest = buffer.substring(start)
                buffer.setLength(0)
                buffer.append(rest)
                break
            }

            val tail = buffer.substring(start)
            when {
                tail.startsWith("\u001B[6n") -> {
                    sendBytes("\u001B[1;1R".toByteArray(Charsets.US_ASCII))
                    buffer.delete(0, start + 4)
                }
                tail.startsWith("\u001B[5n") -> {
                    sendBytes("\u001B[0n".toByteArray(Charsets.US_ASCII))
                    buffer.delete(0, start + 4)
                }
                tail.startsWith("\u001B[c") -> {
                    // VT100-style device attributes response.
                    sendBytes("\u001B[?1;2c".toByteArray(Charsets.US_ASCII))
                    buffer.delete(0, start + 3)
                }
                else -> {
                    // Not a query we own. Preserve it for the visible output.
                    visible.append(buffer.substring(start, start + 1))
                    buffer.delete(0, start + 1)
                }
            }
        }
        return visible.toString()
    }

    fun resize(rows: Int, columns: Int) {
        if (!stopped.get()) NativePty.nativeResize(handle, rows, columns)
    }

    fun stop() {
        if (!stopped.compareAndSet(false, true)) return
        runCatching { input.close() }
        runCatching { output.close() }
        runCatching { pfd.close() }
        NativePty.nativeStop(handle)
    }

    fun isAlive(): Boolean = !stopped.get() && NativePty.nativeIsAlive(handle)
}
