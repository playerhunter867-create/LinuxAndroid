package org.linox.mobile

/**
 * Small native PTY bridge. Unlike ProcessBuilder pipes, this creates a real
 * Unix pseudo-terminal, gives the child a controlling TTY, and connects the
 * PTY master to Java streams.
 */
internal object NativePty {
    init {
        System.loadLibrary("linoxpty")
    }

    external fun nativeStart(
        executable: String,
        args: Array<String>,
        environment: Array<String>,
        workingDirectory: String?
    ): Long

    external fun nativeStop(handle: Long)
    external fun nativeResize(handle: Long, rows: Int, cols: Int)
    external fun nativeIsAlive(handle: Long): Boolean
    external fun nativeFd(handle: Long): Int
}
