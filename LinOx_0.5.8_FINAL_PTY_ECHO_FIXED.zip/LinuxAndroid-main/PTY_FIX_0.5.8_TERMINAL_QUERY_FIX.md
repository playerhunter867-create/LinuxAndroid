# LinOx 0.5.8 terminal query / command echo follow-up fix

The previous PTY fix correctly created a controlling PTY, but the UI is a TextView + EditText rather than a full VT100/VT220 emulator. Running `cat /etc/os-release` could leave the shell/application in a terminal-query state and subsequent command echo became unreliable.

## Changes

- Interactive guest `TERM` is now `dumb`, matching the command-oriented TextView UI.
- This prevents Alpine/BusyBox and other programs from relying on cursor-position/device-status queries that the UI cannot render.
- The defensive CSI query handler remains in place for programs that emit queries explicitly.
- PTY creation, controlling-TTY setup, EIO handling, and resize support remain unchanged.

## Test

Run repeatedly:

```sh
echo one
cat /etc/os-release
echo two
pwd
echo three
ls
echo four
```

All commands should continue to be accepted and echoed after `cat /etc/os-release`, with no `[6n]` text appearing.
