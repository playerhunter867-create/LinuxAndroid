# LinOx 0.5.8 — Professional PTY v2 fix

This revision addresses the interactive-shell hang seen after `cat /etc/os-release`.

## Changes
- Replaced hand-built `posix_openpt`/`setsid`/`TIOCSCTTY` startup with Android Bionic `forkpty()`.
- The child now starts with a real controlling PTY and stdin/stdout/stderr attached atomically.
- Preserved canonical input, echo, signals, CR/LF handling and a 120x40 initial window.
- Kept PTY master blocking and made Java writes serialized.
- Fixed the ANSI/CSI parser so unknown CSI output is preserved as a whole sequence instead of being split/corrupted.
- Terminal status queries (`ESC[6n`, `ESC[5n`, `ESC[c`) are consumed and answered without being printed.
- Kept `TERM=xterm-256color`; no `TERM=dumb` workaround.
- EIO remains treated as PTY EOF rather than a fake terminal error.

The implementation is distro-neutral: Alpine/BusyBox ash, Debian/dash/bash and Ubuntu shells use the same PTY layer.
