# LinOx 0.5.8 — PTY V3 command-loop fix

## Root cause

The previous interactive `/bin/sh -i` design was incompatible with the actual UI.
The UI is an Android `EditText` that submits complete command lines, while the
Alpine BusyBox `ash` line editor is a real terminal line editor. BusyBox ash can
emit `ESC[6n` after a prompt and wait for the terminal to return a cursor
position. This behavior is documented in BusyBox's line editor sources.

LinOx was trying to emulate that terminal query in a Java `TextView`-based UI.
That is not a full VT terminal emulator and could leave ash waiting after
commands such as `cat /etc/os-release`.

## Fix

The PTY itself remains a real Unix PTY created by `forkpty()`.
The guest shell is now a persistent non-interactive `/bin/sh -c` command loop:

* one shell process remains alive for the whole session;
* commands are read line-by-line from the PTY;
* `eval` executes each submitted command in the same shell state;
* `cd`, variables and shell state persist;
* the BusyBox interactive line editor is not started, so no `ESC[6n` prompt
  query can deadlock the session;
* the PTY is still available to programs launched by a command.

This matches the current Android UI architecture: EditText is the line editor.

## Regression test

The session must survive this sequence:

    echo one
    cat /etc/os-release
    echo two
    pwd
    echo three
    ls
    echo four

The command loop was also tested with the same sequence using `/bin/sh -c` on
Linux; `cat /etc/os-release` returned and subsequent commands executed.
