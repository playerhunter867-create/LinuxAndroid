# LinOx Alpine 0.10.4 — stability fix

This build is focused on Alpine runtime stability on modern Android.

Changes:
- removed the unnecessary PRoot `--link2symlink` option;
- removed host `/proc` and `/dev` binds from the Alpine PRoot baseline;
- kept PRoot seccomp disabled for Android compatibility;
- kept rootfs, HOME and TMP binds in app-private storage;
- kept target SDK 28 required by this rootless PRoot design;
- bumped LinOx version to 0.10.4.

The ZIP contains the existing bundled PRoot binary; it does not silently replace it
with an unverified third-party binary. If Alpine still exits with code 255 after
this build, the next step is to replace/test the bundled PRoot implementation
itself rather than changing random Alpine shell options.
