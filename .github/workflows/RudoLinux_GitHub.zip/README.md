# RudoLinux

RudoLinux is a starting point for a Linux-like Android terminal application.

## Build on GitHub

Push the repository to GitHub and open:

Actions -> Build RudoLinux APK -> Run workflow

The generated APK will be available in the workflow Artifacts.

## Current version

0.1 — Android shell-style UI with basic built-in commands.

Next planned steps:
- real PTY terminal
- Linux userspace/rootfs
- package manager
- file manager
- SSH
- multiple terminal tabs
