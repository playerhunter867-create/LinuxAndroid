# LinOx 0.10.10 — persistent shell transport fix

## What changed

PRoot is intentionally unchanged.

The isolated PRoot diagnostics from 0.10.9 passed, including the long-lived
shell sequence. The remaining failure was therefore narrowed to the Android
pipe-backed persistent shell path.

0.10.10 replaces the direct long-lived interactive `/bin/sh` input path with a
small POSIX command loop:

- one `/bin/sh` process stays alive;
- each submitted line is read from stdin;
- the line is evaluated in the same shell;
- `cd`, `export`, shell variables, aliases and normal shell state persist;
- the command exit code is printed as `[LinOx] command exit=N`;
- no PRoot binary or rootfs replacement is performed.

## Test after installing

Run these in order:

```text
echo hello
pwd
ls -la /
cd /tmp
pwd
echo test > linox-test.txt
cat linox-test.txt
python3 --version
```

For Alpine tools, use the TOOLS button first, then test:

```text
python3 --version
nano test.py
git --version
curl --version
```

If the shell still exits, send the complete output including the
`[LinOx] command exit=...` markers. That will tell us whether the guest command
returned a non-zero status or the transport process itself died.
