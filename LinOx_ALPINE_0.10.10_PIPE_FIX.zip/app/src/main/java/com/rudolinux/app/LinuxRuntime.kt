package org.linox.mobile

import android.content.Context
import android.net.Uri
import android.os.Build
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.io.RandomAccessFile
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.Paths
import java.util.concurrent.TimeUnit
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.archivers.tar.TarArchiveEntry

/**
 * Rootless Linux runtime for LinOx.
 *
 * Android stays the host kernel.
 * PRoot supplies the Linux rootfs view.
 * No root access is required.
 *
 * Android stability note: the runtime intentionally avoids binding the whole
 * host /dev tree into Alpine. Individual device nodes are sufficient for the
 * normal shell/package-manager workload and avoid a class of PRoot crashes on
 * newer Android kernels.
 */
class LinuxRuntime(private val context: Context, private val requestedDistroId: String? = null) {

    private val runtimeDir = File(context.filesDir, "linox-runtime")

    // IMPORTANT: PRoot must NOT be copied to filesDir/runtimeDir.
    // Modern Android can mount app data with execution restrictions, which
    // caused error=13 (Permission denied) for the old files/linox-runtime/proot.
    //
    // jniLibs/arm64-v8a/libproot.so is extracted by Android into this native
    // library directory during app installation. We execute it directly from
    // there instead of copying it into filesDir.
    private val proot = File(context.applicationInfo.nativeLibraryDir, "libproot.so")

    private val rootfs = File(runtimeDir, "rootfs")
    private val home = File(runtimeDir, "home")
    private val tmp = File(runtimeDir, "tmp")
    // PRoot creates its own host-side temporary/glue rootfs.
    // Android may reject the default temp location, so force it into
    // LinOx private app storage where the app has write permission.
    private val prootTmp = File(runtimeDir, "proot-tmp")

    private var activeRootfsFile = rootfs
    private var prootError: String? = null

    init {
        installLayout()
        ensureBundledProot()

        val saved = context
            .getSharedPreferences("linox", Context.MODE_PRIVATE)
            .getString("active_rootfs", null)

        if (!saved.isNullOrBlank()) {
            val candidate = runCatching {
                File(saved).canonicalFile
            }.getOrNull()

            if (
                candidate != null &&
                candidate.isDirectory &&
                isAllowedRootfsPath(candidate) &&
                hasUsableShell(candidate)
            ) {
                activeRootfsFile = candidate
            }
        }

        // DistroManager stores downloaded distributions in private app storage:
        // <filesDir>/linox/distros/<id>/rootfs
        // Keeping the rootfs in private app storage is important on Android:
        // shared/external storage can be mounted noexec, which makes /bin/sh
        // appear non-executable to PRoot.
        requestedDistroId
            ?.let { findInstalledDistroRootfs(it) }
            ?.let { activeRootfsFile = it }
    }

    fun installLayout(): File {
        runtimeDir.mkdirs()
        rootfs.mkdirs()
        home.mkdirs()
        tmp.mkdirs()
        prootTmp.mkdirs()

        // Make both directories explicitly usable by the current app UID.
        for (dir in listOf(tmp, prootTmp, home, runtimeDir)) {
            dir.setReadable(true, true)
            dir.setWritable(true, true)
            dir.setExecutable(true, true)
        }

        return runtimeDir
    }

    // -------------------------------------------------------------------------
    // STATUS
    // -------------------------------------------------------------------------

    fun hasProot(): Boolean =
        proot.isFile &&
            proot.length() >= 4096L &&
            isArm64Elf(proot) &&
            prootError == null

    fun isLinuxReady(): Boolean =
        hasProot() &&
            activeRootfsFile.isDirectory &&
            (
                File(activeRootfsFile, "bin/sh").isFile ||
                    File(activeRootfsFile, "usr/bin/sh").isFile
            ) &&
            File(activeRootfsFile, "etc").isDirectory

    fun status(): String = when {
        isLinuxReady() ->
            "Linux userspace: READY"

        prootError != null ->
            "PRoot error: $prootError"

        !hasProot() &&
            (
                File(activeRootfsFile, "bin/sh").isFile ||
                    File(activeRootfsFile, "usr/bin/sh").isFile
            ) ->
            "Linux rootfs found — PRoot is missing or not executable"

        hasProot() ->
            "PRoot installed — choose a Linux distribution"

        else ->
            "Linux userspace: NOT INSTALLED"
    }

    fun runtimePath(): File = runtimeDir

    fun rootfsPath(): File = activeRootfsFile

    fun activeRootfs(): File = activeRootfsFile

    fun homePath(): File = home

    fun prootPath(): File = proot

    // -------------------------------------------------------------------------
    // ROOTFS SELECTION
    // -------------------------------------------------------------------------

    fun activateRootfs(path: File) {
        val canonical = path.canonicalFile

        require(isAllowedRootfsPath(canonical)) {
            "Rootfs must live inside LinOx app storage"
        }

        require(canonical.isDirectory) {
            "Rootfs does not exist: $canonical"
        }

        require(hasUsableShell(canonical)) {
            "Rootfs has no usable /bin/sh or /usr/bin/sh"
        }

        activeRootfsFile = canonical

        context
            .getSharedPreferences("linox", Context.MODE_PRIVATE)
            .edit()
            .putString("active_rootfs", canonical.absolutePath)
            .apply()

        prepareNetworking()
        installLinOxCommands()
    }

    /**
     * Select a distribution downloaded by RootfsManager.
     *
     * This is the missing bridge between the distro installer and the
     * PRoot runtime: the installer writes to externalFilesDir/linox/distros,
     * while the runtime used to search only filesDir/linox-runtime/rootfs.
     */
    fun activateInstalledDistro(id: String) {
        val candidate = findInstalledDistroRootfs(id)
            ?: error("Linux $id is not installed or has no usable shell.")

        activateRootfs(candidate)
    }

    private fun findInstalledDistroRootfs(id: String): File? {
        require(Regex("[A-Za-z0-9._-]+").matches(id)) {
            "Invalid distribution id"
        }

        val candidate = File(context.filesDir, "linox/distros/$id/rootfs").canonicalFile

        if (
            isAllowedRootfsPath(candidate) &&
            candidate.isDirectory &&
            File(candidate, "etc").isDirectory &&
            hasUsableShell(candidate)
        ) {
            runCatching { normalizeCriticalShell(candidate) }
            if (hasUsableShell(candidate)) return candidate
        }

        // Migrate rootfs produced by older LinOx builds from external app
        // storage into private app storage. This also fixes Android noexec
        // mounts without forcing the user to download Alpine again.
        val legacyExternal = context.getExternalFilesDir(null)?.let {
            File(it, "linox/distros/$id/rootfs").canonicalFile
        }
        if (legacyExternal != null &&
            legacyExternal.isDirectory &&
            hasUsableShell(legacyExternal) &&
            File(legacyExternal, "etc").isDirectory
        ) {
            val parent = candidate.parentFile
            parent?.mkdirs()
            if (!candidate.exists()) {
                legacyExternal.copyRecursively(candidate, overwrite = true)
            }
            if (candidate.isDirectory && hasUsableShell(candidate)) {
                normalizeCriticalShell(candidate)
                return candidate
            }
        }

        return null
    }

    private fun hasUsableShell(root: File): Boolean =
        File(root, "bin/sh").isFile ||
            File(root, "usr/bin/sh").isFile

    fun resetToDefaultRootfs() {
        activeRootfsFile = rootfs.canonicalFile

        context
            .getSharedPreferences("linox", Context.MODE_PRIVATE)
            .edit()
            .remove("active_rootfs")
            .apply()
    }

    // -------------------------------------------------------------------------
    // PROOT
    // -------------------------------------------------------------------------

    /**
     * PRoot is bundled as an AArch64 native executable in jniLibs and cannot
     * be replaced at runtime. Keeping this method explicit prevents callers
     * from accidentally recreating the old filesDir/proot path.
     */
    fun installProot(source: Uri) {
        source // Keep API compatibility with older callers.
        error("LinOx 0.10.9 uses the bundled native PRoot; runtime PRoot replacement is disabled.")
    }

    private fun ensureBundledProot() {
        prootError = null

        if (!isArm64DeviceInternal()) {
            prootError = "This LinOx build contains AArch64 PRoot only."
            return
        }

        if (!proot.isFile || proot.length() < 4096L) {
            prootError =
                "Bundled PRoot is missing from nativeLibraryDir: ${proot.absolutePath}"
            return
        }

        if (!isArm64Elf(proot)) {
            prootError = "Bundled PRoot is not a 64-bit ARM ELF executable."
            return
        }

        val validation = validateProot(proot)
        if (validation != null) {
            prootError = validation
        }
    }

    private fun isArm64DeviceInternal(): Boolean =
        Build.SUPPORTED_ABIS.any { it.equals("arm64-v8a", ignoreCase = true) }

    private fun validateProot(file: File): String? {
        return try {
            // The native library directory is the only supported execution
            // location for the bundled PRoot in LinOx 0.9.0.
            val process = ProcessBuilder(
                file.absolutePath,
                "--version"
            )
                .redirectErrorStream(true)
                .start()

            if (!process.waitFor(8, TimeUnit.SECONDS)) {
                process.destroyForcibly()
                return "PRoot validation timed out."
            }

            val output = process.inputStream
                .bufferedReader()
                .use { it.readText() }
                .trim()

            if (process.exitValue() != 0) {
                return "PRoot exited with code ${process.exitValue()}" +
                    if (output.isNotEmpty()) ": $output" else "."
            }

            null
        } catch (e: Exception) {
            "PRoot cannot execute from Android nativeLibraryDir: " +
                (e.message ?: e.javaClass.simpleName)
        }
    }

    // -------------------------------------------------------------------------
    // ROOTFS INSTALLATION
    // -------------------------------------------------------------------------

    /**
     * Installs a .tar.gz Linux rootfs.
     *
     * Important:
     * Linux rootfs archives contain both symbolic links and hard links.
     * Android storage can reject some link operations, so links are handled
     * separately and hard links are materialized as regular files.
     */
    fun installRootfsTarGz(
        source: Uri,
        onProgress: (String) -> Unit = {}
    ) {
        val staging = File(runtimeDir, "rootfs.new")

        if (staging.exists()) {
            staging.deleteRecursively()
        }

        staging.mkdirs()

        val pendingSymlinks = mutableListOf<PendingSymlink>()
        val pendingHardlinks = mutableListOf<PendingHardlink>()

        try {
            val raw = requireNotNull(
                context.contentResolver.openInputStream(source)
            ) {
                "Unable to open rootfs archive"
            }

            // Keep the stream types explicit here. Some Kotlin compiler versions
            // used by GitHub Actions fail to infer the receiver types for nested
            // use {} blocks in this Android source file.
            val input: InputStream = raw
            try {
                val gzip: java.util.zip.GZIPInputStream = java.util.zip.GZIPInputStream(input.buffered())
                try {
                    val tar = TarArchiveInputStream(gzip)
                    try {
                        var entry: TarArchiveEntry? = tar.nextTarEntry
                        var count = 0

                        while (entry != null) {

                            val current = entry
                                ?: break

                            val name = normalizeArchiveName(
                                current.name
                            )

                            if (name.isEmpty()) {
                                entry = tar.nextTarEntry
                                continue
                            }

                            val target = safeTarget(
                                staging,
                                name
                            )

                            when {

                                // -------------------------------------------------
                                // DIRECTORY
                                // -------------------------------------------------

                                current.isDirectory -> {
                                    target.mkdirs()
                                    applyMode(
                                        target,
                                        current.mode
                                    )
                                }

                                // -------------------------------------------------
                                // SYMBOLIC LINK
                                // -------------------------------------------------

                                current.isSymbolicLink -> {
                                    deleteAny(target)

                                    target.parentFile?.mkdirs()

                                    pendingSymlinks += PendingSymlink(
                                        target = target,
                                        linkName = current.linkName,
                                        entryName = name
                                    )
                                }

                                // -------------------------------------------------
                                // HARD LINK
                                // -------------------------------------------------

                                current.isLink -> {
                                    deleteAny(target)

                                    target.parentFile?.mkdirs()

                                    pendingHardlinks += PendingHardlink(
                                        target = target,
                                        linkName = current.linkName,
                                        entryName = name
                                    )
                                }

                                // -------------------------------------------------
                                // REGULAR FILE
                                // -------------------------------------------------

                                current.isFile -> {
                                    deleteAny(target)

                                    target.parentFile?.mkdirs()

                                    FileOutputStream(target).use { output ->
                                        tar.copyTo(output)
                                    }

                                    applyMode(
                                        target,
                                        current.mode
                                    )
                                }

                                // -------------------------------------------------
                                // OTHER TAR ENTRY
                                // -------------------------------------------------

                                else -> {
                                    // Device nodes, FIFOs, etc. cannot safely be
                                    // created inside normal Android app storage.
                                    // Skip them instead of aborting the entire
                                    // rootfs installation.
                                }
                            }

                            count++

                            if (count % 250 == 0) {
                                onProgress(
                                    "Extracted $count files…"
                                )
                            }

                            entry = tar.nextTarEntry
                        }
                    } finally {
                        tar.close()
                    }
                } finally {
                    gzip.close()
                }
            } finally {
                input.close()
            }

            onProgress("Restoring hard links…")

            restoreHardlinks(
                staging,
                pendingHardlinks
            )

            onProgress("Restoring symbolic links…")

            restoreSymlinks(
                staging,
                pendingSymlinks
            )

            // -------------------------------------------------------------
            // ROOTFS VALIDATION
            // -------------------------------------------------------------

            require(
                File(staging, "bin/sh").isFile ||
                    File(staging, "usr/bin/sh").isFile
            ) {
                "Invalid rootfs: no /bin/sh or /usr/bin/sh"
            }

            // Android filesystems and PRoot do not always preserve executable
            // symlink chains exactly as a normal Linux filesystem would.
            // Materialize the shell entry as a real executable file.
            normalizeCriticalShell(staging)

            require(
                File(staging, "etc").isDirectory
            ) {
                "Invalid rootfs: /etc was not found"
            }

            // Some rootfs archives contain /bin -> usr/bin.
            // Check that /bin or /usr/bin exists.
            require(
                File(staging, "bin").exists() ||
                    File(staging, "usr/bin").exists()
            ) {
                "Invalid rootfs: no usable binary directory"
            }

            // -------------------------------------------------------------
            // ACTIVATE ROOTFS
            // -------------------------------------------------------------

            if (rootfs.exists()) {
                rootfs.deleteRecursively()
            }

            check(staging.renameTo(rootfs)) {
                "Could not activate rootfs"
            }

            activeRootfsFile = rootfs.canonicalFile

            context
                .getSharedPreferences(
                    "linox",
                    Context.MODE_PRIVATE
                )
                .edit()
                .remove("active_rootfs")
                .apply()

            prepareNetworking()
            installLinOxCommands()

            onProgress(
                "Linux rootfs installed successfully"
            )

        } catch (e: Exception) {

            staging.deleteRecursively()

            throw e
        }
    }

    private fun normalizeCriticalShell(root: File) {
        val candidates = listOf(
            File(root, "bin/sh"),
            File(root, "usr/bin/sh")
        )

        for (shell in candidates) {
            if (!shell.exists()) continue

            val target = resolveExecutableFile(root, shell) ?: continue
            if (!target.isFile) continue

            // If /bin/sh is already a regular file, just force execute bits.
            if (!Files.isSymbolicLink(shell.toPath())) {
                shell.setReadable(true, false)
                shell.setExecutable(true, false)
                return
            }

            val replacement = File(shell.parentFile, ".sh-materialized")
            replacement.delete()
            target.inputStream().use { input ->
                FileOutputStream(replacement).use { output ->
                    input.copyTo(output)
                }
            }
            replacement.setReadable(true, false)
            replacement.setWritable(true, false)
            replacement.setExecutable(true, false)
            deleteAny(shell)
            check(replacement.renameTo(shell)) {
                "Could not materialize ${shell.path}"
            }
            return
        }
    }

    private fun resolveExecutableFile(root: File, start: File): File? {
        var current = start
        repeat(12) {
            if (current.isFile && !Files.isSymbolicLink(current.toPath())) {
                return current
            }
            if (!Files.isSymbolicLink(current.toPath())) return null

            val link = Files.readSymbolicLink(current.toPath()).toString()
            val next = if (link.startsWith("/")) {
                File(root, link.removePrefix("/"))
            } else {
                File(current.parentFile, link)
            }.canonicalFile

            val rootPath = root.canonicalPath
            check(next.path == rootPath || next.path.startsWith(rootPath + File.separator)) {
                "Unsafe shell symlink target"
            }
            current = next
        }
        return null
    }

    // -------------------------------------------------------------------------
    // HARD LINKS
    // -------------------------------------------------------------------------

    private fun restoreHardlinks(
        base: File,
        links: List<PendingHardlink>
    ) {
        for (link in links) {

            val target = safeTarget(
                base,
                normalizeArchiveName(
                    relativeArchivePath(
                        base,
                        link.linkName
                    )
                )
            )

            val destination = link.target

            if (!target.exists()) {
                // Hard-link target may itself be another hard-link.
                // Nothing to do yet; a later pass may resolve it.
                continue
            }

            deleteAny(destination)
            destination.parentFile?.mkdirs()

            copyFileOrDirectory(
                target,
                destination
            )
        }

        // Second pass handles chains of hard links.
        for (link in links) {

            if (link.target.exists()) {
                continue
            }

            val normalized = normalizeLinkTarget(
                link.target,
                link.linkName,
                base
            )

            val source = safeTarget(
                base,
                normalized
            )

            if (source.exists()) {
                link.target.parentFile?.mkdirs()

                copyFileOrDirectory(
                    source,
                    link.target
                )
            }
        }
    }

    // -------------------------------------------------------------------------
    // SYMBOLIC LINKS
    // -------------------------------------------------------------------------

    private fun restoreSymlinks(
        base: File,
        links: List<PendingSymlink>
    ) {
        // Multiple passes are intentional.
        // Linux rootfs archives frequently contain chains such as:
        //
        // /bin -> usr/bin
        // /usr/bin/sh -> dash
        //
        // We try to create real links first. If Android refuses a link,
        // we materialize the target instead.
        repeat(3) {

            for (link in links) {

                if (
                    Files.isSymbolicLink(
                        link.target.toPath()
                    )
                ) {
                    continue
                }

                if (link.target.exists()) {
                    continue
                }

                link.target.parentFile?.mkdirs()

                val resolved = resolveLinkTarget(
                    base,
                    link.target,
                    link.linkName
                )

                val created = runCatching {
                    createSymbolicLinkCompat(
                        link.target,
                        link.linkName
                    )
                }.isSuccess

                if (created) {
                    continue
                }

                // Android may reject symlink creation on some filesystems.
                // If the target already exists, materialize it.
                if (resolved != null && resolved.exists()) {

                    runCatching {
                        copyFileOrDirectory(
                            resolved,
                            link.target
                        )
                    }
                }
            }
        }
    }

    private fun createSymbolicLinkCompat(
        target: File,
        linkName: String
    ) {
        require(linkName.isNotEmpty()) {
            "Empty symlink target"
        }

        deleteAny(target)

        target.parentFile?.mkdirs()

        Files.createSymbolicLink(
            target.toPath(),
            Paths.get(linkName)
        )
    }

    // -------------------------------------------------------------------------
    // LINK RESOLUTION
    // -------------------------------------------------------------------------

    private fun resolveLinkTarget(
        base: File,
        linkFile: File,
        linkName: String
    ): File? {

        return runCatching {

            val rawTarget = Paths.get(linkName)

            val resolved: Path =
                if (rawTarget.isAbsolute) {
                    base.toPath().resolve(
                        rawTarget.toString()
                            .removePrefix("/")
                    )
                } else {
                    linkFile.parentFile
                        .toPath()
                        .resolve(rawTarget)
                }

            val canonical = resolved
                .normalize()
                .toFile()

            val baseCanonical =
                base.canonicalFile

            val canonicalPath =
                canonical.canonicalPath

            require(
                canonicalPath == baseCanonical.path ||
                    canonicalPath.startsWith(
                        baseCanonical.path +
                            File.separator
                    )
            ) {
                "Unsafe symlink target: $linkName"
            }

            canonical
        }.getOrNull()
    }

    private fun normalizeLinkTarget(
        linkFile: File,
        linkName: String,
        base: File
    ): String {

        val resolved = resolveLinkTarget(
            base,
            linkFile,
            linkName
        ) ?: return ""

        val basePath =
            base.canonicalPath

        val resolvedPath =
            resolved.canonicalPath

        return if (
            resolvedPath == basePath
        ) {
            ""
        } else {
            resolvedPath
                .removePrefix(
                    basePath + File.separator
                )
        }
    }

    private fun relativeArchivePath(
        base: File,
        path: String
    ): String {
        if (path.startsWith("/")) {
            return path.removePrefix("/")
        }

        return path
    }

    // -------------------------------------------------------------------------
    // COPY HELPERS
    // -------------------------------------------------------------------------

    private fun copyFileOrDirectory(
        source: File,
        destination: File
    ) {

        if (source.isDirectory) {

            destination.mkdirs()

            source.listFiles()?.forEach { child ->

                val target =
                    File(destination, child.name)

                copyFileOrDirectory(
                    child,
                    target
                )
            }

        } else if (source.isFile) {

            destination.parentFile?.mkdirs()

            source.inputStream().use { input ->
                FileOutputStream(destination).use { output ->
                    input.copyTo(output)
                }
            }

            destination.setReadable(
                source.canRead(),
                false
            )

            destination.setWritable(
                source.canWrite(),
                false
            )

            destination.setExecutable(
                source.canExecute(),
                false
            )
        }
    }

    // -------------------------------------------------------------------------
    // NETWORK
    // -------------------------------------------------------------------------

    /**
     * Android network is reused by PRoot.
     * This only supplies DNS inside the guest.
     */
    fun prepareNetworking() {

        if (!activeRootfsFile.isDirectory) {
            return
        }

        val etc =
            File(activeRootfsFile, "etc")

        etc.mkdirs()

        val resolv =
            File(etc, "resolv.conf")

        val dns = listOf(
            readAndroidProperty("net.dns1"),
            readAndroidProperty("net.dns2"),
            readAndroidProperty("net.dns3"),
            readAndroidProperty("net.dns4")
        )
            .filter {
                it.isNotBlank() &&
                    it != "0.0.0.0"
            }
            .distinct()

        val servers =
            if (dns.isNotEmpty()) {
                dns
            } else {
                listOf(
                    "1.1.1.1",
                    "8.8.8.8"
                )
            }

        runCatching {

            if (
                Files.isSymbolicLink(
                    resolv.toPath()
                ) ||
                resolv.exists()
            ) {
                resolv.delete()
            }

            resolv.writeText(
                servers.joinToString("\n") {
                    "nameserver $it"
                } + "\n"
            )
        }

        File(
            etc,
            "hostname"
        ).writeText("linox\n")
    }

    // -------------------------------------------------------------------------
    // DEVELOPMENT TOOLS
    // -------------------------------------------------------------------------

    fun bootstrapDevelopmentTools(
        packageManager: String
    ) {

        check(isLinuxReady()) {
            "Linux rootfs is not ready"
        }

        prepareNetworking()

        val command =
            when (packageManager.lowercase()) {

                "apt" ->
                    "export DEBIAN_FRONTEND=noninteractive; " +
                        "apt-get update -y && " +
                        "apt-get install -y " +
                        "python3 python3-pip nano git curl wget " +
                        "ca-certificates bash"

                "apk" ->
                    "set -e; " +
                        "echo '[LinOx] Refreshing Alpine repositories...'; " +
                        "ok=0; " +
                        "for i in 1 2 3; do apk update && { ok=1; break; }; " +
                        "echo '[LinOx] apk update failed, retrying...'; sleep 2; done; " +
                        "if [ \"${'\$'}ok\" -ne 1 ]; then echo '[LinOx] apk update failed after 3 attempts.'; exit 20; fi; " +
                        "echo '[LinOx] Installing Python, Nano and core tools...'; " +
                        "apk add --no-cache python3 python3-dev py3-pip py3-virtualenv nano vim git curl wget ca-certificates bash " +
                        "coreutils findutils grep sed gawk procps iproute2 bind-tools tar gzip unzip zip less file tree " +
                        "build-base cmake pkgconf musl-dev libffi-dev openssh-client openssl jq sqlite util-linux; " +
                        "update-ca-certificates >/dev/null 2>&1 || true; " +
                        "echo '[LinOx] Alpine developer environment ready.'"

                "dnf" ->
                    "dnf -y install " +
                        "python3 python3-pip nano git curl wget " +
                        "ca-certificates bash"

                "pacman" ->
                    "pacman -Sy --noconfirm " +
                        "python python-pip nano git curl wget " +
                        "ca-certificates bash"

                "zypper" ->
                    "zypper --non-interactive refresh && " +
                        "zypper --non-interactive install -y " +
                        "python3 python3-pip nano git curl wget " +
                        "ca-certificates bash"

                else ->
                    "true"
            }

        val result =
            execute(
                command,
                20 * 60
            )

        require(result.exitCode == 0) {
            "Developer tools installation failed " +
                "(exit ${result.exitCode}): " +
                result.output.takeLast(4000)
        }

        execute(
            "if command -v python3 >/dev/null 2>&1 && " +
                "! command -v python >/dev/null 2>&1; then " +
                "ln -s \"$(command -v python3)\" " +
                "/usr/local/bin/python 2>/dev/null || true; fi",
            30
        )

        execute(
            "if command -v pip3 >/dev/null 2>&1 && " +
                "! command -v pip >/dev/null 2>&1; then " +
                "ln -s \"$(command -v pip3)\" " +
                "/usr/local/bin/pip 2>/dev/null || true; fi",
            30
        )

        installLinOxCommands()
    }

    // -------------------------------------------------------------------------
    // LINOX COMMANDS
    // -------------------------------------------------------------------------

    fun installLinOxCommands() {

        if (!activeRootfsFile.isDirectory) {
            return
        }

        prepareNetworking()

        val bin =
            File(
                activeRootfsFile,
                "usr/local/bin"
            )

        bin.mkdirs()

        File(bin, "linox-info").apply {

            writeText(
                """
                #!/bin/sh
                echo "LinOx Mobile 0.10.10"
                echo "Userspace: ${'$'}(cat /etc/os-release 2>/dev/null | sed -n '1p' || echo Linux)"
                echo "Architecture: ${'$'}(uname -m)"
                echo "Host kernel: ${'$'}(uname -sr)"
                echo "Python: ${'$'}(python --version 2>&1 || python3 --version 2>&1 || echo not-installed)"
                echo "Git: ${'$'}(git --version 2>/dev/null || echo not-installed)"
                echo "Nano: ${'$'}(nano --version 2>/dev/null | head -n 1 || echo not-installed)"
                """.trimIndent() + "\n"
            )

            setExecutable(
                true,
                false
            )
        }

        File(bin, "linox-doctor").apply {

            writeText(
                """
                #!/bin/sh
                ok=0
                command -v sh >/dev/null 2>&1 && echo "[OK] shell" || { echo "[FAIL] shell"; ok=1; }
                command -v python3 >/dev/null 2>&1 || command -v python >/dev/null 2>&1 && echo "[OK] Python" || echo "[WARN] Python not installed"
                command -v git >/dev/null 2>&1 && echo "[OK] Git" || echo "[WARN] Git not installed"
                command -v curl >/dev/null 2>&1 && echo "[OK] curl" || echo "[WARN] curl not installed"
                command -v wget >/dev/null 2>&1 && echo "[OK] wget" || echo "[WARN] wget not installed"
                command -v nano >/dev/null 2>&1 && echo "[OK] nano" || echo "[WARN] nano not installed"
                if command -v apk >/dev/null 2>&1; then echo "[OK] apk (Alpine)"; fi
                if command -v apt-get >/dev/null 2>&1; then echo "[OK] apt (Debian/Ubuntu)"; fi
                test -f /etc/resolv.conf && echo "[OK] DNS configuration" || echo "[WARN] /etc/resolv.conf missing"
                printf "Kernel: "
                uname -sr
                printf "Arch: "
                uname -m
                exit ${'$'}ok
                """.trimIndent() + "\n"
            )

            setExecutable(
                true,
                false
            )
        }

        File(bin, "linox").apply {

            writeText(
                """
                #!/bin/sh
                case "${'$'}1" in
                  info) linox-info ;;
                  doctor) linox-doctor ;;
                  alpine) exec /usr/local/bin/linox-alpine-setup ;;
                  shell) exec /bin/sh ;;
                  *) echo "LinOx commands: info | doctor | alpine | shell" ;;
                esac
                """.trimIndent() + "\n"
            )

            setExecutable(
                true,
                false
            )
        }

        File(bin, "linox-alpine-setup").apply {
            writeText(
                """
                #!/bin/sh
                set -e
                if ! command -v apk >/dev/null 2>&1; then
                  echo "LinOx Alpine setup: this is not an Alpine rootfs."
                  exit 2
                fi
                echo "[LinOx] Alpine setup: updating repositories..."
                ok=0
                for i in 1 2 3; do
                  if apk update; then ok=1; break; fi
                  echo "[LinOx] apk update failed (attempt ${'$'}i/3), retrying..."
                  sleep 2
                done
                if [ "${'$'}ok" -ne 1 ]; then
                  echo "[LinOx] ERROR: apk update failed after 3 attempts."
                  echo "Check DNS/network with: cat /etc/resolv.conf"
                  exit 20
                fi
                echo "[LinOx] Installing Python, Nano and core tools..."
                apk add --no-cache python3 python3-dev py3-pip py3-virtualenv nano vim git curl wget ca-certificates bash \
                  coreutils findutils grep sed gawk procps iproute2 bind-tools tar gzip unzip zip less file tree \
                  build-base cmake pkgconf musl-dev libffi-dev openssh-client openssl jq sqlite util-linux
                update-ca-certificates >/dev/null 2>&1 || true
                echo "[LinOx] Alpine setup complete."
                echo "Python: ${'$'}(python3 --version 2>&1 || true)"
                echo "Git: ${'$'}(git --version 2>&1 || true)"
                echo "curl: ${'$'}(curl --version 2>&1 | head -n 1 || true)"
                """.trimIndent() + "\n"
            )
            setExecutable(true, false)
        }

        File(bin, "python").apply {
            writeText("#!/bin/sh\nexec python3 \"${'$'}@\"\n")
            setExecutable(true, false)
        }

        File(bin, "pip").apply {
            writeText("#!/bin/sh\nexec pip3 \"${'$'}@\"\n")
            setExecutable(true, false)
        }

        File(bin, "py").apply {
            writeText("#!/bin/sh\nexec python3 \"${'$'}@\"\n")
            setExecutable(true, false)
        }

        File(bin, "ll").apply {

            if (!exists()) {

                writeText(
                    "#!/bin/sh\n" +
                        "ls -lah \"${'$'}@\"\n"
                )

                setExecutable(
                    true,
                    false
                )
            }
        }

        val profile =
            File(
                activeRootfsFile,
                "etc/profile.d/linox.sh"
            )

        profile.parentFile?.mkdirs()

        profile.writeText(
            """
            export TERM="${'$'}{TERM:-xterm-256color}"
            export PATH="/usr/local/bin:/usr/local/sbin:/usr/bin:/usr/sbin:/bin:/sbin:${'$'}PATH"
            export LANG="${'$'}{LANG:-C.UTF-8}"
            """.trimIndent() + "\n"
        )
    }

    /**
     * Alpine-specific runtime preparation.
     *
     * The Android UI is not a real TTY. BusyBox ash prints
     * "can't access tty; job control turned off" when started with -i
     * on a pipe. That warning is harmless in itself, but interactive ash
     * can terminate on some PRoot/Android combinations. We therefore keep
     * the guest shell non-interactive and persistent, while the app supplies
     * commands through the long-lived stdin pipe.
     *
     * We also provide the standard proc/dev/sys views that common Alpine
     * tools expect. PRoot performs these as user-space binds; no Android
     * root is required.
     */
    private fun prepareAlpineRuntime() {
        if (requestedDistroId != "alpine") return

        val root = activeRootfsFile
        File(root, "tmp").mkdirs()
        File(root, "run").mkdirs()
        File(root, "proc").mkdirs()
        File(root, "dev").mkdirs()
        File(root, "sys").mkdirs()
        File(root, "root").mkdirs()

        File(root, "tmp").setReadable(true, false)
        File(root, "tmp").setWritable(true, false)
        File(root, "tmp").setExecutable(true, false)

        val repositories = File(root, "etc/apk/repositories")
        repositories.parentFile?.mkdirs()

        // The official Alpine 3.24 image normally contains this already.
        // Recreate it if an extracted image lost the file or contained only
        // a local-media repository.
        val repoText =
            "https://dl-cdn.alpinelinux.org/alpine/v3.24/main\n" +
            "https://dl-cdn.alpinelinux.org/alpine/v3.24/community\n"

        // The rootfs is Alpine 3.24, so always use matching official repositories.
        // This avoids stale media/old-release entries after a repaired install.
        runCatching { repositories.writeText(repoText) }

        File(root, "etc/profile.d/linox-alpine.sh").apply {
            parentFile?.mkdirs()
            writeText(
                """
                export TERM="${'$'}{TERM:-xterm-256color}"
                export LANG="${'$'}{LANG:-C.UTF-8}"
                export LC_ALL="${'$'}{LC_ALL:-C.UTF-8}"
                export HOME="/root"
                export PATH="/usr/local/bin:/usr/local/sbin:/usr/bin:/usr/sbin:/bin:/sbin:${'$'}PATH"
                export PS1="${'$'}{PS1:-\u@\h:\w\$ }"
                """.trimIndent() + "\n"
            )
        }

        File(root, "etc/hostname").writeText("linox\n")

        // Keep Alpine's BusyBox applet symlinks intact.  PRoot must see the
        // original /bin/ls -> busybox style layout; copying BusyBox over every
        // applet can make filesystem-heavy commands unnecessarily fragile.
    }

    private fun materializeAlpineExecutableLinks(root: File) {
        if (requestedDistroId != "alpine") return

        val dirs = listOf(
            File(root, "bin"),
            File(root, "sbin"),
            File(root, "usr/bin"),
            File(root, "usr/sbin")
        )

        for (dir in dirs) {
            val entries = runCatching {
                dir.listFiles()?.toList().orEmpty()
            }.getOrDefault(emptyList())

            for (entry in entries) {
                if (!Files.isSymbolicLink(entry.toPath())) continue

                val target = runCatching {
                    resolveExecutableFile(root, entry)
                }.getOrNull() ?: continue

                if (!target.isFile || !target.canExecute()) continue

                val replacement = File(
                    entry.parentFile,
                    ".linox-${entry.name}-materialized"
                )

                runCatching {
                    deleteAny(replacement)
                    target.inputStream().use { input ->
                        FileOutputStream(replacement).use { output ->
                            input.copyTo(output)
                        }
                    }
                    replacement.setReadable(true, false)
                    replacement.setWritable(true, false)
                    replacement.setExecutable(true, false)
                    deleteAny(entry)
                    check(replacement.renameTo(entry)) {
                        "Could not materialize ${entry.path}"
                    }
                }.onFailure {
                    deleteAny(replacement)
                }
            }
        }
    }

    /** Resolve a Linux guest path to the corresponding Android-private file. */
    fun resolveGuestPath(path: String): File {
        val raw = path.trim()
        require(raw.isNotEmpty()) { "Empty path" }

        val base = when {
            raw == "/root" || raw.startsWith("/root/") -> home
            raw == "/tmp" || raw.startsWith("/tmp/") -> tmp
            raw.startsWith("/") -> activeRootfsFile
            else -> home
        }

        val relative = when {
            raw == "/root" -> ""
            raw.startsWith("/root/") -> raw.removePrefix("/root/")
            raw == "/tmp" -> ""
            raw.startsWith("/tmp/") -> raw.removePrefix("/tmp/")
            raw.startsWith("/") -> raw.removePrefix("/")
            else -> raw
        }

        val candidate = File(base, relative).canonicalFile
        val allowed = base.canonicalFile
        require(candidate.path == allowed.path || candidate.path.startsWith(allowed.path + File.separator)) {
            "Path escapes Linux storage"
        }
        return candidate
    }

    // -------------------------------------------------------------------------
    // INTERACTIVE TERMINAL
    // -------------------------------------------------------------------------

    /**
     * Runs isolated PRoot probes without starting the persistent shell.
     * This is intentionally separate from the interactive session so we can
     * identify whether PRoot itself, guest /bin/sh, cwd handling, or a guest
     * command such as ls is the first failing component.
     */
    fun runProotDiagnostics(): String {
        if (!hasProot()) {
            return "PRoot diagnostic: NOT READY\n${prootError ?: "unknown PRoot error"}"
        }
        if (!activeRootfsFile.isDirectory) {
            return "PRoot diagnostic: rootfs is missing: ${activeRootfsFile.absolutePath}"
        }

        val out = StringBuilder()
        out.append("[PRoot] binary: ${proot.absolutePath}\n")
        out.append("[PRoot] size: ${proot.length()} bytes\n")
        out.append("[PRoot] PROOT_NO_SECCOMP=1\n")

        probeProot(out, "version", listOf("--version"), null)
        probeProot(out, "shell-no-cwd", listOf("-0", "-r", activeRootfsFile.absolutePath, "/bin/sh", "-c", "echo PROOT_SHELL_OK"), null)
        probeProot(out, "shell-cwd-root", listOf("-0", "-r", activeRootfsFile.absolutePath, "-w", "/", "/bin/sh", "-c", "pwd; echo PROOT_CWD_ROOT_OK"), null)
        probeProot(out, "shell-cwd-home", listOf("-0", "-r", activeRootfsFile.absolutePath, "-w", "/root", "/bin/sh", "-c", "pwd; echo PROOT_CWD_HOME_OK"), null)
        probeProot(out, "ls-root", listOf("-0", "-r", activeRootfsFile.absolutePath, "-w", "/root", "/bin/sh", "-c", "ls / >/dev/null && echo PROOT_LS_OK"), null)
        probeProot(out, "cat-release", listOf("-0", "-r", activeRootfsFile.absolutePath, "-w", "/root", "/bin/sh", "-c", "cat /etc/alpine-release"), null)

        // Critical A/B probe: this uses the SAME PRoot arguments as the
        // persistent shell, but drives a single long-lived /bin/sh with a
        // sequence of commands and explicit markers. If this passes while
        // the real session later dies on `ls`, the failure is in the Android
        // stdin/transport path rather than in PRoot/rootfs itself.
        probePersistentSequence(out)

        return out.toString()
    }

    private fun probePersistentSequence(out: StringBuilder) {
        out.append("\n[PRoot probe: persistent-sequence]\n")
        val script = """
            echo PERSISTENT_START
            pwd
            echo BEFORE_LS
            ls
            echo AFTER_LS
            echo PERSISTENT_END
            exit 0
        """.trimIndent()

        try {
            val process = ProcessBuilder(
                proot.absolutePath,
                "--kill-on-exit",
                "-0",
                "-r", activeRootfsFile.absolutePath,
                "-w", "/root",
                "/bin/sh"
            )
                .redirectErrorStream(true)
                .apply {
                    environment()["PROOT_NO_SECCOMP"] = "1"
                    environment()["PROOT_DONT_POLLUTE_ROOTFS"] = "1"
                    environment()["PROOT_TMP_DIR"] = prootTmp.absolutePath
                    environment()["HOME"] = "/root"
                    environment()["PATH"] = "/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin"
                }
                .start()

            process.outputStream.bufferedWriter().use { writer ->
                writer.write(script)
                writer.write("\n")
                writer.flush()
            }

            val output = process.inputStream.bufferedReader().use { it.readText() }
            val finished = process.waitFor(6, TimeUnit.SECONDS)
            if (!finished) {
                process.destroyForcibly()
                out.append("RESULT=TIMEOUT\n")
                return
            }

            out.append("EXIT=${process.exitValue()}\n")
            if (output.isNotBlank()) out.append(output.trimEnd()).append('\n')

            val pass = process.exitValue() == 0 &&
                output.contains("PERSISTENT_START") &&
                output.contains("BEFORE_LS") &&
                output.contains("AFTER_LS") &&
                output.contains("PERSISTENT_END")

            out.append(if (pass) "PERSISTENT_SEQUENCE=PASS\n" else "PERSISTENT_SEQUENCE=FAIL\n")
        } catch (e: Exception) {
            out.append("RESULT=EXCEPTION ${e.javaClass.simpleName}: ${e.message}\n")
            out.append("PERSISTENT_SEQUENCE=FAIL\n")
        }
    }

    private fun probeProot(
        out: StringBuilder,
        name: String,
        args: List<String>,
        hostCwd: String?
    ) {
        out.append("\n[PRoot probe: $name]\n")
        try {
            val process = ProcessBuilder(proot.absolutePath, *args.toTypedArray())
                .redirectErrorStream(true)
                .apply {
                    if (hostCwd != null) directory(File(hostCwd))
                    environment()["PROOT_NO_SECCOMP"] = "1"
                    environment()["PROOT_DONT_POLLUTE_ROOTFS"] = "1"
                    environment()["PROOT_TMP_DIR"] = prootTmp.absolutePath
                    environment()["HOME"] = "/root"
                    environment()["PATH"] = "/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin"
                }
                .start()

            val output = StringBuilder()
            val reader = Thread {
                runCatching {
                    process.inputStream.bufferedReader().useLines { lines ->
                        lines.forEach { line ->
                            if (output.length < 4096) output.append(line).append('\n')
                        }
                    }
                }
            }
            reader.isDaemon = true
            reader.start()

            val finished = process.waitFor(4, TimeUnit.SECONDS)
            if (!finished) {
                process.destroyForcibly()
                out.append("RESULT=TIMEOUT\n")
            } else {
                reader.join(1000)
                out.append("EXIT=${process.exitValue()}\n")
            }
            if (output.length > 0) out.append(output)
        } catch (e: Exception) {
            out.append("RESULT=EXCEPTION ${e.javaClass.simpleName}: ${e.message}\n")
        }
    }

    fun startInteractivePty(
        onText: (String) -> Unit
    ): PtySession {

        if (!hasProot()) {
            error(
                "PRoot is not ready." +
                    (prootError?.let { " $it" } ?: " Bundled ARM64 PRoot is missing or invalid.")
            )
        }

        if (!activeRootfsFile.isDirectory) {
            error("Linux rootfs is not installed: ${activeRootfsFile.path}")
        }

        if (!File(activeRootfsFile, "etc").isDirectory) {
            error("Linux rootfs is incomplete: /etc is missing.")
        }

        if (!(
            File(activeRootfsFile, "bin/sh").isFile ||
                File(activeRootfsFile, "usr/bin/sh").isFile
        )) {
            error("Linux rootfs is incomplete: /bin/sh or /usr/bin/sh is missing.")
        }

        prepareNetworking()
        installLinOxCommands()
        prepareAlpineRuntime()

        // Android ProcessBuilder gives the guest shell ordinary pipes, not a
        // real controlling TTY.  A long-lived interactive ash/bash process can
        // behave differently when commands are fed through a pipe, especially
        // around EOF and job-control handling.  Keep the Linux shell persistent,
        // but put a tiny POSIX command loop in front of it.  Each line received
        // from the Android command box is evaluated in the SAME guest shell, so
        // cd/export/variables remain persistent without requiring a PTY.
        //
        // This is deliberately distro-neutral: Alpine uses BusyBox ash while
        // Debian/Ubuntu may use dash/bash.  /bin/sh is the only required shell.
        val shell = listOf(
            "/bin/sh",
            "-c",
            """
            while IFS= read -r __linox_cmd; do
                [ -z "$__linox_cmd" ] && continue
                eval "$__linox_cmd"
                __linox_rc=$?
                printf '\n[LinOx] command exit=%s\n' "$__linox_rc"
            done
            exit 0
            """.trimIndent()
        )

        val env =
            linkedMapOf(
                "HOME" to "/root",
                "TERM" to "xterm-256color",
                "TMPDIR" to "/tmp",
                "LANG" to "C.UTF-8",
                "LC_ALL" to "C.UTF-8",
                "PS1" to "\\u@linox:\\w\\$ ",
                "PS2" to "> ",
                "PROOT_NO_SECCOMP" to "1",
                "PROOT_DONT_POLLUTE_ROOTFS" to "1",
                "PROOT_TMP_DIR" to prootTmp.absolutePath,
                "LINOX_ANDROID_HOME" to home.absolutePath,
                "LINOX_SHELL_TRANSPORT" to "pipe-command-loop",
                "PATH" to
                    "/usr/local/bin:" +
                    "/usr/local/sbin:" +
                    "/usr/bin:" +
                    "/usr/sbin:" +
                    "/bin:/sbin"
            )

        // Android 10+ execution restrictions are controlled by the app target SDK.
        // LinOx deliberately targets API 28 (while compiling with API 35) because
        // the Linux guest binaries live in writable app-private storage.
        // If the app was accidentally rebuilt with targetSdk >= 29, PRoot can
        // start but execve(/bin/sh) fails with Permission denied.
        if (Build.VERSION.SDK_INT >= 29 && context.applicationInfo.targetSdkVersion >= 29) {
            error(
                "LinOx requires targetSdkVersion 28 for PRoot guest execution on Android 10+. " +
                    "Current targetSdk=${context.applicationInfo.targetSdkVersion}."
            )
        }

        val session =
            PtySession.start(
                proot.absolutePath,
                baseProotArgs() + shell,
                env,
                // Do not pass the Android-side home as the host cwd.
                // PRoot establishes the guest cwd via -w /root.
                null
            )

        session.readLoop(
            onText
        ) {}

        return session
    }

    // -------------------------------------------------------------------------
    // COMMAND EXECUTION
    // -------------------------------------------------------------------------

    fun execute(
        command: String,
        timeoutSeconds: Long = 60
    ): CommandResult {

        if (command.isBlank()) {
            return CommandResult(
                "",
                0
            )
        }

        val linux =
            isLinuxReady()

        if (linux) {
            prepareNetworking()
            installLinOxCommands()
        }

        val args =
            if (linux) {

                baseProotArgs() +
                    listOf(
                        "/bin/sh",
                        "-lc",
                        "cd /root && " + command
                    )

            } else {

                listOf(
                    "/system/bin/sh",
                    "-lc",
                    command
                )
            }

        return try {

            val process =
                ProcessBuilder(args)
                    .directory(
                        if (linux)
                            runtimeDir
                        else
                            context.filesDir
                    )
                    .redirectErrorStream(true)
                    .apply {

                        environment()["HOME"] =
                            if (linux)
                                "/root"
                            else
                                home.absolutePath

                        environment()["LINOX_ANDROID_HOME"] =
                            home.absolutePath

                        environment()["TERM"] =
                            "xterm-256color"

                        environment()["LANG"] =
                            "C.UTF-8"

                        environment()["LC_ALL"] =
                            "C.UTF-8"

                        environment()["PROOT_NO_SECCOMP"] =
                            "1"

                        environment()["PROOT_TMP_DIR"] =
                            prootTmp.absolutePath

                        environment()["TMPDIR"] =
                            if (linux)
                                "/tmp"
                            else
                                tmp.absolutePath

                        if (linux) {

                            environment()["PATH"] =
                                "/usr/local/bin:" +
                                "/usr/local/sbin:" +
                                "/usr/bin:" +
                                "/usr/sbin:" +
                                "/bin:/sbin"
                        }
                    }
                    .start()

            val output =
                StringBuilder()

            val readerThread =
                Thread {

                    runCatching {

                        process.inputStream
                            .bufferedReader()
                            .use { reader ->

                                val buffer =
                                    CharArray(8192)

                                while (true) {

                                    val n =
                                        reader.read(buffer)

                                    if (n < 0) {
                                        break
                                    }

                                    synchronized(output) {
                                        output.append(
                                            buffer,
                                            0,
                                            n
                                        )
                                    }
                                }
                            }
                    }
                }.apply {

                    name =
                        "LinOx-command-output"

                    isDaemon = true

                    start()
                }

            val finished =
                process.waitFor(
                    timeoutSeconds,
                    TimeUnit.SECONDS
                )

            if (!finished) {

                process.destroyForcibly()

                process.waitFor(
                    2,
                    TimeUnit.SECONDS
                )

                readerThread.join(2000)

                CommandResult(
                    synchronized(output) {
                        output.toString()
                    } +
                        "\n[LinOx] command timed out",
                    124
                )

            } else {

                readerThread.join(2000)

                CommandResult(
                    synchronized(output) {
                        output.toString()
                    },
                    process.exitValue()
                )
            }

        } catch (e: Exception) {

            CommandResult(
                "[LinOx] " +
                    "${e.javaClass.simpleName}: " +
                    e.message,
                1
            )
        }
    }

    // -------------------------------------------------------------------------
    // PROOT ARGUMENTS
    // -------------------------------------------------------------------------

    private fun baseProotArgs(): List<String> =
        buildList {
            addAll(
                listOf(
                    // Keep the process tree under control, but avoid
                    // Android-host /dev directory binding. Binding the entire
                    // Android /dev tree is unnecessarily broad and can make
                    // ordinary commands such as `ls` terminate PRoot on some
                    // Android 15 kernels. The guest gets only the device nodes
                    // that normal CLI programs need below.
                    // Keep the PRoot command line deliberately minimal on
                    // Android 15/16.  In particular, do not use
                    // --link2symlink: it is unnecessary for Alpine and can
                    // make filesystem-heavy programs unstable with some
                    // PRoot builds.
                    "--kill-on-exit",
                    "-0",
                    "-r",
                    activeRootfsFile.absolutePath,
                    "-w",
                    "/root"
                )
            )

            // Do not bind Android /root, /tmp, /proc or /dev into the guest.
            // The previous /root -> Android app-storage bind was especially
            // fragile: ordinary commands such as `ls` could make PRoot 5.3.x
            // terminate with exit code 255 while walking the bound directory.
            //
            // Alpine now uses its own persistent /root and /tmp directories.
            // That keeps files persistent without exposing Android storage to
            // the guest's current working directory.
        }

    // -------------------------------------------------------------------------
    // ARCHIVE SAFETY
    // -------------------------------------------------------------------------

    private fun normalizeArchiveName(
        raw: String
    ): String {

        val name =
            raw
                .replace('\\', '/')
                .trimStart('/')

        val parts =
            name
                .split('/')
                .filter {
                    it.isNotEmpty() &&
                        it != "."
                }

        require(
            parts.none {
                it == ".."
            }
        ) {
            "Unsafe archive entry: $raw"
        }

        return parts.joinToString("/")
    }

    private fun safeTarget(
        base: File,
        name: String
    ): File {

        val root =
            base.canonicalFile

        val target =
            File(
                root,
                name
            ).canonicalFile

        require(
            target.path == root.path ||
                target.path.startsWith(
                    root.path +
                        File.separator
                )
        ) {
            "Unsafe archive path: $name"
        }

        return target
    }

    // -------------------------------------------------------------------------
    // FILE HELPERS
    // -------------------------------------------------------------------------

    private fun deleteAny(
        file: File
    ) {

        if (
            file.exists() ||
            Files.isSymbolicLink(
                file.toPath()
            )
        ) {
            file.deleteRecursively()
        }
    }

    private fun applyMode(
        file: File,
        mode: Int
    ) {

        file.setReadable(
            (mode and 0b100_100_100) != 0,
            false
        )

        file.setWritable(
            (mode and 0b010_010_010) != 0,
            false
        )

        file.setExecutable(
            (mode and 0b001_001_001) != 0,
            false
        )
    }

    // -------------------------------------------------------------------------
    // PATH / SECURITY
    // -------------------------------------------------------------------------

    private fun isAllowedRootfsPath(
        candidate: File
    ): Boolean {

        val path = candidate.canonicalFile.path

        val allowedRoots = buildList {
            add(context.filesDir.canonicalFile)
            context.getExternalFilesDir(null)
                ?.let { add(it.canonicalFile) }
        }

        return allowedRoots.any { root ->
            path == root.path ||
                path.startsWith(root.path + File.separator)
        }
    }

    // -------------------------------------------------------------------------
    // ANDROID PROPERTIES
    // -------------------------------------------------------------------------

    private fun readAndroidProperty(
        name: String
    ): String =
        runCatching {

            Runtime.getRuntime()
                .exec(
                    arrayOf(
                        "/system/bin/getprop",
                        name
                    )
                )
                .inputStream
                .bufferedReader()
                .use {
                    it.readText().trim()
                }

        }.getOrDefault("")

    // -------------------------------------------------------------------------
    // ELF CHECK
    // -------------------------------------------------------------------------

    private fun isArm64Elf(
        file: File
    ): Boolean =
        runCatching {

            RandomAccessFile(
                file,
                "r"
            ).use { raf ->

                val ident =
                    ByteArray(20)

                raf.readFully(
                    ident
                )

                ident[0] ==
                    0x7f.toByte() &&

                    ident[1] ==
                    'E'.code.toByte() &&

                    ident[2] ==
                    'L'.code.toByte() &&

                    ident[3] ==
                    'F'.code.toByte() &&

                    ident[4].toInt() == 2 &&

                    ident[5].toInt() == 1 &&

                    (ident[18].toInt() and 0xff) == 183
            }

        }.getOrDefault(false)

    // -------------------------------------------------------------------------
    // DEVICE INFO
    // -------------------------------------------------------------------------

    fun architecture(): String =
        Build.SUPPORTED_ABIS
            .firstOrNull()
            ?: "unknown"

    fun isArm64Device(): Boolean =
        Build.SUPPORTED_ABIS.any {
            it == "arm64-v8a"
        }

    fun storageUsedBytes(): Long {

        fun dirSize(
            file: File
        ): Long {

            return if (file.isFile) {

                file.length()

            } else {

                file.listFiles()
                    ?.sumOf(::dirSize)
                    ?: 0L
            }
        }

        return dirSize(runtimeDir) +
            dirSize(
                File(
                    context.filesDir,
                    "linox-distros"
                )
            )
    }

    // -------------------------------------------------------------------------
    // INTERNAL LINK DATA
    // -------------------------------------------------------------------------

    private data class PendingSymlink(
        val target: File,
        val linkName: String,
        val entryName: String
    )

    private data class PendingHardlink(
        val target: File,
        val linkName: String,
        val entryName: String
    )

    // -------------------------------------------------------------------------
    // RESULT
    // -------------------------------------------------------------------------

    data class CommandResult(
        val output: String,
        val exitCode: Int
    )
}
