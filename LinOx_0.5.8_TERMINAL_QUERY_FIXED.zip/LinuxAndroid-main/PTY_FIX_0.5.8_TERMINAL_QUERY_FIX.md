# LinOx 0.5.8 — terminal query / `[6n` fix

This revision fixes the remaining interactive-shell lockup seen after the PTY/EIO fix.

Symptoms were:
- `[6n` appeared directly in the visible terminal output.
- The first command could be entered/executed, but later commands stopped being displayed or processed.
- Alpine/BusyBox could be waiting for a terminal cursor-position response.

Cause:
The Android UI is a command-oriented terminal surface, not a complete VT100/ANSI emulator. A guest process can send the terminal query `ESC [ 6 n` (CSI 6 n) and wait for the terminal to answer with the current cursor position. Previously LinOx displayed the tail as `[6n` and never sent the response.

Fix:
- Detect CSI 6 n in the PTY reader, including sequences split across reads.
- Respond with a valid cursor-position response (`ESC [ 1 ; 1 R`).
- Handle CSI 5 n and the basic device-attributes query as well.
- Do not display these terminal queries as text.
- Keep the existing real controlling PTY and EIO handling.

After rebuilding, `echo hello`, `cat /etc/os-release`, `pwd`, `ls`, and subsequent commands should continue working instead of hanging after the first command.
