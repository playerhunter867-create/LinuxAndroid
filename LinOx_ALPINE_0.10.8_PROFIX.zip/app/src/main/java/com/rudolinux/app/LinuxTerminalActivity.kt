package org.linox.mobile

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Stable persistent-shell terminal for LinOx. */
class LinuxTerminalActivity : Activity() {
    private lateinit var output: TextView
    private lateinit var input: EditText
    private lateinit var scroll: ScrollView
    private lateinit var runtime: LinuxRuntime
    private var session: PtySession? = null
    private val history = ArrayList<String>()
    private var historyIndex = 0
    private var lastSubmitAt = 0L
    private var shellStarting = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = intent.getStringExtra("distro_id") ?: "alpine"
        val manager = DistroManager(this)
        val distro = manager.available.firstOrNull { it.id == id } ?: manager.getDefault()
        runtime = LinuxRuntime(this, id)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(7, 10, 13))
            setPadding(10, 10, 10, 8)
        }

        val title = TextView(this).apply {
            text = "${distro.name} ${distro.version}  •  LinOx 0.10.8"
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(124, 255, 178))
            setPadding(2, 0, 2, 6)
        }

        output = TextView(this).apply {
            textSize = 14f
            typeface = Typeface.MONOSPACE
            setTextColor(Color.rgb(224, 232, 228))
            setTextIsSelectable(true)
            text = "LinOx 0.10.8\nStarting ${distro.name}...\n"
            setPadding(4, 10, 4, 10)
        }

        scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(output)
        }

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        input = EditText(this).apply {
            hint = "command"
            setSingleLine(true)
            imeOptions = EditorInfo.IME_ACTION_DONE
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            textSize = 14f
            typeface = Typeface.MONOSPACE
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            setPadding(8, 0, 8, 0)
            setOnKeyListener { _, keyCode, event ->
                if (event.action != KeyEvent.ACTION_DOWN) return@setOnKeyListener false
                when (keyCode) {
                    KeyEvent.KEYCODE_DPAD_UP -> { historyMove(-1); true }
                    KeyEvent.KEYCODE_DPAD_DOWN -> { historyMove(1); true }
                    else -> false
                }
            }
        }

        val run = Button(this).apply {
            text = "RUN"
            setOnClickListener { submitCommand() }
        }
        val clear = Button(this).apply {
            text = "CLR"
            setOnClickListener { output.text = "" }
        }

        val restart = Button(this).apply {
            text = "RESTART"
            setOnClickListener { startShell() }
        }

        val tools = Button(this).apply {
            text = "TOOLS"
            setOnClickListener { installAlpineTools() }
        }

        input.setOnEditorActionListener { _, actionId, event ->
            val enter = event?.keyCode == KeyEvent.KEYCODE_ENTER
            if (actionId == EditorInfo.IME_ACTION_DONE || enter) {
                submitCommand()
                true
            } else false
        }

        row.addView(input, LinearLayout.LayoutParams(0, 56, 1f))
        row.addView(run, LinearLayout.LayoutParams(78, 56))
        row.addView(clear, LinearLayout.LayoutParams(68, 56))
        row.addView(restart, LinearLayout.LayoutParams(92, 56))
        row.addView(tools, LinearLayout.LayoutParams(78, 56))

        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(row)
        setContentView(root)

        try {
            runtime.activateInstalledDistro(id)
            startShell()
            input.requestFocus()
        } catch (e: Exception) {
            output.append("\n[ERROR] ${e.message ?: e.javaClass.simpleName}\n")
            Toast.makeText(this, e.message ?: "Runtime error", Toast.LENGTH_LONG).show()
        }
    }

    private fun startShell() {
        if (shellStarting) return
        if (session?.isAlive() == true) return

        shellStarting = true
        session?.stop()
        session = null

        output.append("\n[LinOx] Running PRoot diagnostics...\n")

        try {
            Thread {
                val diagnostics = runtime.runProotDiagnostics()
                runOnUiThread {
                    output.append(diagnostics)
                    output.append("\n[LinOx] PRoot probes passed. Starting persistent Linux shell...\n")
                    startShellAfterDiagnostics()
                }
            }.apply { isDaemon = true }.start()
        } catch (e: Exception) {
            output.append("\n[PRoot diagnostics ERROR] ${e.message ?: e.javaClass.simpleName}\n")
            shellStarting = false
        }
    }

    private fun startShellAfterDiagnostics() {
        try {
            session = runtime.startInteractivePty { text ->
                runOnUiThread {
                    output.append(text)
                    scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
                }
            }

            session?.let { active ->
                active.setOnExit { code ->
                    runOnUiThread {
                        if (session === active) {
                            session = null
                            output.append(
                                "\n[LinOx] Linux shell exited (code $code). " +
                                    "Press RESTART to start it again.\n"
                            )
                        }
                    }
                }
            }

            output.append("✓ PRoot ready\n✓ Persistent shell ready\n\n")
        } catch (e: Exception) {
            output.append("\n[ERROR] ${e.message ?: e.javaClass.simpleName}\n")
            Toast.makeText(this, e.message ?: "Runtime error", Toast.LENGTH_LONG).show()
        } finally {
            shellStarting = false
        }
    }

    private fun submitCommand() {
        val now = System.currentTimeMillis()
        if (now - lastSubmitAt < 120) return
        lastSubmitAt = now

        val cmd = input.text.toString().trimEnd('\r', '\n')
        if (cmd.isBlank()) return
        val active = session
        if (active == null || !active.isAlive()) {
            output.append("\n[LinOx] Linux shell is not running.\n")
            return
        }

        if (history.lastOrNull() != cmd) history.add(cmd)
        if (history.size > 100) history.removeAt(0)
        historyIndex = history.size

        val nanoPath = parseNanoCommand(cmd)
        if (runtimeIsAlpine() && nanoPath != null) {
            output.append("\n$cmd\n[LinOx] Opening nano editor...\n")
            input.text.clear()
            startActivityForResult(
                Intent(this, NanoEditorActivity::class.java)
                    .putExtra("distro_id", "alpine")
                    .putExtra("path", nanoPath),
                REQUEST_NANO
            )
            return
        }

        output.append("\n$cmd\n")
        active.send(cmd)
        input.text.clear()
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private fun runtimeIsAlpine(): Boolean =
        intent.getStringExtra("distro_id") == "alpine"

    private fun parseNanoCommand(command: String): String? {
        val parts = command.trim().split(Regex("\\s+"), limit = 3)
        if (parts.isEmpty() || parts[0] != "nano") return null
        if (parts.size < 2 || parts[1].startsWith("-")) return null
        return parts[1]
    }

    private fun installAlpineTools() {
        if (!runtimeIsAlpine()) {
            output.append("\n[LinOx] TOOLS is currently Alpine-only.\n")
            return
        }
        val active = session
        if (active == null || !active.isAlive()) {
            output.append("\n[LinOx] Linux shell is not running.\n")
            return
        }
        output.append(
            "\n[LinOx] Installing Alpine developer tools...\n" +
                "Python3 + pip + nano + vim + git + curl + wget + build tools + utilities\n"
        )
        active.send("linox alpine")
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: android.content.Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_NANO) {
            output.append(
                if (resultCode == RESULT_OK)
                    "\n[LinOx] nano: file saved.\n"
                else
                    "\n[LinOx] nano: editor closed.\n"
            )
            scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
            input.requestFocus()
        }
    }

    private fun historyMove(delta: Int) {
        if (history.isEmpty()) return
        historyIndex = (historyIndex + delta).coerceIn(0, history.size)
        input.setText(if (historyIndex == history.size) "" else history[historyIndex])
        input.setSelection(input.length())
    }

    override fun onDestroy() {
        session?.stop()
        session = null
        super.onDestroy()
    }

    companion object {
        private const val REQUEST_NANO = 4101
    }
}
