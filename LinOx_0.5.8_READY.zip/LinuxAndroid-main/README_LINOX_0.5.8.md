# LinOx 0.5.8

Rootless Linux runtime for Android (ARM64).

## PRoot fix

PRoot is packaged as `app/src/main/jniLibs/arm64-v8a/libproot.so` and executed
directly from Android's `ApplicationInfo.nativeLibraryDir`.

The app no longer copies PRoot into `files/linox-runtime/`, avoiding the
Android `error=13, Permission denied` execution failure seen in LinOx 0.5.7.

RootFS files stay in the app's private `files/` storage.

## Build

GitHub Actions:
- push to `main`, or
- Actions -> Build LinOx 0.5.8 APK

Artifact: `LinOx-0.5.8-APK`.

This build is ARM64 (`arm64-v8a`) because the bundled PRoot is AArch64.
