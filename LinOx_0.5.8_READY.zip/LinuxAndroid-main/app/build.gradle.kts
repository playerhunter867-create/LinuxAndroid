plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "org.linox.mobile"
    compileSdk = 35

    defaultConfig {
        applicationId = "org.linox.mobile"
        minSdk = 26
        targetSdk = 35
        versionCode = 11
        versionName = "0.5.8"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    // PRoot is shipped as a prebuilt AArch64 native executable under jniLibs.
    // Android installs it into ApplicationInfo.nativeLibraryDir, which is the
    // executable native-library location rather than app filesDir.
    packaging {
        jniLibs {
            useLegacyPackaging = true
            // PRoot is an executable stored with a .so name so Android
            // extracts it into nativeLibraryDir. Do not strip it.
            keepDebugSymbols += "**/libproot.so"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("org.apache.commons:commons-compress:1.27.1")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
}
