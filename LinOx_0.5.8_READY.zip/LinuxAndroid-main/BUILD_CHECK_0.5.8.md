# LinOx 0.5.8 — PRoot execution fix

## What changed

- Removed the old runtime copy path:
  `files/linox-runtime/proot` / `files/linox-runtime/proot`
- Bundled PRoot is now stored as:
  `app/src/main/jniLibs/arm64-v8a/libproot.so`
- `LinuxRuntime` executes the binary directly from:
  `ApplicationInfo.nativeLibraryDir/libproot.so`
- APK is explicitly configured to package native libraries without legacy
  packaging.
- RootFS remains in private app storage under `files/linox/distros/.../rootfs`.
- The build is AArch64/arm64-v8a only because the bundled PRoot is AArch64.

## Expected runtime path

APK -> Android nativeLibraryDir/libproot.so -> PRoot -> Alpine/Debian/Ubuntu rootfs

The app must never create or execute `files/linox-runtime/proot`.

## GitHub Actions

Run **Actions -> Build LinOx 0.5.8 APK** (or push to `main`).
The workflow uploads `LinOx-0.5.8-APK/app-debug.apk`.
