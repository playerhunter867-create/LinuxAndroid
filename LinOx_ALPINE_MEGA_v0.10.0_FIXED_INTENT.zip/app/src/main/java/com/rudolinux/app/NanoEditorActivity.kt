package org.linox.mobile

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.nio.charset.StandardCharsets

/**
 * Small Android-backed editor for `nano file` when the guest has no real TTY.
 * It intentionally behaves like a normal file editor: open, edit, save.
 * The file is resolved inside the active Linux guest storage, so `nano test.py`
 * in /root creates /root/test.py and Python can execute it afterwards.
 */
class NanoEditorActivity : Activity() {
    private lateinit var editor: EditText
    private lateinit var runtime: LinuxRuntime
    private lateinit var filePath: String
    private lateinit var title: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val distroId = intent.getStringExtra("distro_id") ?: "alpine"
        filePath = intent.getStringExtra("path")?.trim().orEmpty()
        runtime = LinuxRuntime(this, distroId)

        if (filePath.isBlank()) {
            finishWithError("nano: missing file name")
            return
        }

        val file = try {
            runtime.resolveGuestPath(filePath)
        } catch (e: Exception) {
            finishWithError("nano: ${e.message ?: "invalid path"}")
            return
        }

        title = TextView(this).apply {
            text = "nano  •  ${displayPath(filePath)}"
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(124, 255, 178))
            setPadding(8, 8, 8, 8)
        }

        editor = EditText(this).apply {
            gravity = Gravity.TOP or Gravity.START
            typeface = Typeface.MONOSPACE
            textSize = 14f
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            setBackgroundColor(Color.rgb(10, 14, 18))
            setPadding(12, 12, 12, 12)
            setSingleLine(false)
            isVerticalScrollBarEnabled = true
            setHorizontallyScrolling(true)
            overScrollMode = android.view.View.OVER_SCROLL_ALWAYS
        }

        val save = Button(this).apply {
            text = "SAVE"
            setOnClickListener { saveFile(file) }
        }

        val cancel = Button(this).apply {
            text = "CANCEL"
            setOnClickListener { finish() }
        }

        val buttons = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(save, LinearLayout.LayoutParams(0, 56, 1f))
            addView(cancel, LinearLayout.LayoutParams(0, 56, 1f))
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(7, 10, 13))
            addView(title, LinearLayout.LayoutParams(-1, -2))
            addView(editor, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(buttons, LinearLayout.LayoutParams(-1, -2))
        }

        setContentView(root)

        try {
            if (file.isFile) {
                if (file.length() > 2L * 1024L * 1024L) {
                    finishWithError("nano: file is larger than 2 MiB")
                    return
                }
                editor.setText(file.readText(StandardCharsets.UTF_8))
                editor.setSelection(editor.length())
            }
            editor.requestFocus()
        } catch (e: Exception) {
            finishWithError("nano: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    private fun saveFile(file: java.io.File) {
        try {
            file.parentFile?.mkdirs()
            file.writeText(editor.text.toString(), StandardCharsets.UTF_8)
            Toast.makeText(this, "Saved ${displayPath(filePath)}", Toast.LENGTH_SHORT).show()
            setResult(RESULT_OK)
        } catch (e: Exception) {
            Toast.makeText(this, "Save failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun displayPath(path: String): String =
        if (path.startsWith("/")) path else "/root/$path"

    private fun finishWithError(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
        setResult(RESULT_CANCELED)
        finish()
    }
}
