# Build check — LinOx 0.5.7

Checked before packaging:

- project structure is complete;
- bundled PRoot asset is an ELF 64-bit AArch64 executable;
- bundled PRoot identifies as v5.3.0;
- SHA-256 of bundled PRoot:
  `fa10b1a7818c2f5b1dcb5834450570c368c9ecf66d31521509621b95c4538a45`;
- Kotlin source was parsed with the local Kotlin compiler; Android SDK classes are unavailable in this environment, so a complete Android Gradle build could not be executed here;
- GitHub Actions is configured to build with Java 17 and Gradle 8.7.

The final runtime behavior still needs one real Android-device test because PRoot depends on the device's Android kernel/ptrace behavior.
