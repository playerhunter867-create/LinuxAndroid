LinOx 0.5.4 notes

This historical note is kept only for project history. The active release is LinOx 0.5.7.

See README_LINOX_0.5.7.md for the current build and troubleshooting information.
