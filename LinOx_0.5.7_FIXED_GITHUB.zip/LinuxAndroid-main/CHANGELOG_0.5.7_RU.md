# LinOx 0.5.7

## Исправлено

- Убран тихий `runCatching` вокруг установки PRoot: причина ошибки теперь не теряется.
- Встроенный PRoot проверяется как AArch64 ELF и запускается с `--version` до использования.
- Исправлен misleading error `Install an ARM64 PRoot and a Linux ARM64 distribution first`.
- После распаковки OCI rootfs принудительно проверяется `/bin/sh` / `/usr/bin/sh`.
- Alpine `/bin/sh` теперь материализуется из BusyBox, если symlink нельзя безопасно сохранить.
- Debian/Ubuntu shell symlink также может быть материализован.
- `isInstalled()` и runtime используют согласованную проверку shell.
- Добавлен `REINSTALL / REPAIR` для уже установленных дистрибутивов.
- Улучшены сообщения о повреждённом rootfs и PRoot.
- Версия APK поднята до 0.5.7 (versionCode 10).
- Обновлён GitHub Actions artifact до `LinOx-0.5.7-APK`.

## Архитектура

- Android host kernel.
- ARM64 Linux userspace.
- PRoot без root-доступа.
- OCI/Docker layers с SHA-256 проверкой.
- Rootfs в private app storage.
