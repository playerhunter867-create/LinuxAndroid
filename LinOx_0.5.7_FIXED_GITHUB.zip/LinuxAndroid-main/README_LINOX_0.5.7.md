# LinOx 0.5.7 — Android ARM64 Linux userspace

LinOx runs real ARM64 Linux userspaces on Android without root by combining an Android-compatible PRoot runtime with OCI/Docker Linux root filesystems.

## 0.5.7 fixes

### Fixed: `Install an ARM64 PRoot and a Linux ARM64 distribution first`

The runtime no longer silently ignores a failed PRoot installation/validation.

At startup it now:

- verifies that the bundled binary is a 64-bit AArch64 ELF;
- validates that PRoot can actually execute with `--version`;
- reports the real validation error instead of hiding it behind the generic message;
- re-validates an existing bundled PRoot after an app update;
- keeps PRoot temporary/glue files inside private app storage;
- uses `PROOT_NO_SECCOMP=1` for Android kernels where PRoot seccomp acceleration is unavailable.

### Fixed: Alpine says `installed`, but there is no `START LINUX`

The rootfs installer and runtime now use the same shell checks.

After OCI extraction LinOx explicitly validates:

- `/etc/os-release`;
- `/etc`;
- `/bin/sh` or `/usr/bin/sh`.

If Android storage cannot preserve the distro's `/bin/sh` symlink, LinOx resolves the target (for example Alpine's BusyBox shell) and materializes a real executable `/bin/sh`.

This prevents the exact state where the installer reports success but the distribution manager still shows `PREPARE / DOWNLOAD`.

### Fixed: installed Ubuntu/Debian cannot be started

The selected distro is explicitly activated before the terminal starts.

The runtime searches:

`<filesDir>/linox/distros/<distro-id>/rootfs`

and migrates compatible rootfs data from older external app-storage layouts.

### Rootfs safety

- Docker/OCI layer digests are SHA-256 verified.
- OCI whiteouts are applied before layer extraction.
- Archive path traversal is rejected.
- Linux hard links are materialized safely.
- Symlinks are resolved/retried and critical shell links can be materialized.
- Rootfs data stays in private application storage.

## Bundled PRoot

The APK contains an AArch64 static PRoot binary. The bundled binary identifies itself as PRoot `v5.3.0` and is validated at runtime before Linux is started.

SHA-256:

```text
fa10b1a7818c2f5b1dcb5834450570c368c9ecf66d31521509621b95c4538a45
```

## Supported images

| ID | Distribution | Image | Architecture |
|---|---|---|---|
| `debian12` | Debian 12 | `library/debian:12` | linux/arm64 |
| `ubuntu2404` | Ubuntu 24.04 LTS | `library/ubuntu:24.04` | linux/arm64 |
| `ubuntu2204` | Ubuntu 22.04 LTS | `library/ubuntu:22.04` | linux/arm64 |
| `alpine` | Alpine Linux 3.24 | `library/alpine:3.24` | linux/arm64 |

Alpine 3.24 is an official Alpine release with an `aarch64` download.

## Clean upgrade recommended

For testing 0.5.7, uninstall the previous LinOx APK first if you do not need its installed rootfses. This guarantees there are no stale PRoot/rootfs files from 0.5.6.

Then:

1. Install the new APK.
2. Open **DISTRIBUTIONS**.
3. Choose **Alpine Linux 3.24**.
4. Press **PREPARE / DOWNLOAD**.
5. Wait for `RootFS verified and installed`.
6. The button should change to **START LINUX**.
7. Press **START LINUX**.

Inside Linux test:

```sh
uname -m
cat /etc/os-release
ls -l /bin/sh
printf 'LinOx OK\n'
```

Expected architecture:

```text
aarch64
```

## If startup still fails

The terminal now shows the underlying reason instead of the old generic message.

Useful diagnostics are:

```text
PRoot validation failed
Linux rootfs is incomplete
/bin/sh ... missing
PRoot cannot execute on this Android device
```

This makes device-specific Android/PRoot restrictions distinguishable from a broken downloaded distribution.

## Build on GitHub

The repository includes:

`.github/workflows/build.yml`

The workflow:

- uses Java 17;
- uses Gradle 8.7;
- builds `:app:assembleDebug`;
- uploads `LinOx-0.5.7-APK`.

Run it from **Actions → Build LinOx 0.5.7 APK → Run workflow**.

## Important limitation

LinOx is a rootless Linux userspace, not a second Android kernel or a full virtual machine. Android remains the host kernel and PRoot translates the Linux filesystem/process view. Some Linux features that require real kernel namespaces, mounts, device nodes, or privileged operations may therefore remain unavailable.
