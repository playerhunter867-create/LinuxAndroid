# LinOx 0.5.8

Rootless Linux runtime for Android (ARM64).

## PRoot fix

PRoot is packaged as `app/src/main/jniLibs/arm64-v8a/libproot.so` and executed
directly from Android's `ApplicationInfo.nativeLibraryDir`.

The app no longer copies PRoot into `files/linox-runtime/`, avoiding the
Android `error=13, Permission denied` execution failure seen in LinOx 0.5.7.

RootFS files stay in the app's private `files/` storage.

## Build

GitHub Actions:
- push to `main`, or
- Actions -> Build LinOx 0.5.8 APK

Artifact: `LinOx-0.5.8-APK`.

This build is ARM64 (`arm64-v8a`) because the bundled PRoot is AArch64.


Build-fix revision: arm64-v8a ABI is explicitly selected and the debug workflow verifies SDK, PRoot ELF format, and APK native payload before uploading.


## 0.5.8 runtime compatibility fix

LinOx intentionally uses `targetSdk = 28` while compiling against API 35. This is not a Gradle workaround: Android 10 introduced execution restrictions for apps targeting API 29+ that execute native binaries from writable app data. LinOx/PRoot needs to execute the Linux guest's `/bin/sh` and other rootfs binaries from private app storage. Keeping targetSdk 28 preserves the compatibility behavior used by Termux for this class of workload.

PRoot itself remains packaged as `app/src/main/jniLibs/arm64-v8a/libproot.so` and is extracted by Android into `nativeLibraryDir`. The Linux rootfs remains in private app storage.
