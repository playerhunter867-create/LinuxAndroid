# LinOx 0.10.7 — Alpine/PRoot diagnostic build

This build intentionally rolls back the experimental Alpine cwd changes from 0.10.6.

## What changed
- Alpine interactive shell is back to the 0.10.5 launch path: `/bin/sh`.
- PRoot arguments are back to the 0.10.5 path, including `-w /root`.
- The Alpine rootfs is not replaced.
- The bundled PRoot binary is **not replaced** in this build. It remains the bundled ARM64 PRoot 5.3.0 so that PRoot replacement can be tested as a separate, controlled step.
- On shell start, LinOx runs short isolated PRoot probes before opening the persistent shell.

## Diagnostic probes
1. `proot --version`
2. PRoot + `/bin/sh` without explicit guest cwd
3. PRoot + `-w /`
4. PRoot + `-w /root`
5. PRoot + `ls /`
6. PRoot + `cat /etc/alpine-release`

Each probe prints its exit code and captured PRoot stderr/stdout. A timeout is 4 seconds per probe.

## Why PRoot is separate
PRoot 5.4.0 is a meaningful candidate for the next controlled test because its official release notes list an Android cwd compatibility fix. We are deliberately not changing the binary in 0.10.7, so the next test can change only PRoot and compare the same runtime.
