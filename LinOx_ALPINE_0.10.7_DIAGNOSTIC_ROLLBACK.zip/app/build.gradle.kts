plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "org.linox.mobile"
    compileSdk = 35

    defaultConfig {
        applicationId = "org.linox.mobile"
        minSdk = 26
        // IMPORTANT: Keep targetSdk at 28. LinOx/PRoot executes Linux guest
        // binaries from writable app-private storage. Android 10+ restricts
        // exec() from writable app data for apps targeting API 29+.
        // compileSdk may stay modern; this is specifically a runtime
        // compatibility requirement for the rootless Linux userspace.
        targetSdk = 28

        // LinOx ships one PRoot binary: AArch64/arm64-v8a.
        // Restrict the APK to this ABI so Gradle never tries to build/package
        // an unsupported native architecture.
        ndk {
            abiFilters += "arm64-v8a"
        }

        versionCode = 25
        versionName = "0.10.7"

    }

    // PRoot is shipped as a prebuilt AArch64 native executable under jniLibs.
    // Android installs it into ApplicationInfo.nativeLibraryDir, which is the
    // executable native-library location rather than app filesDir.
    packaging {
        jniLibs {
            useLegacyPackaging = true
            // PRoot is an executable stored with a .so name so Android
            // extracts it into nativeLibraryDir. Do not strip it.
            keepDebugSymbols += "**/libproot.so"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("org.apache.commons:commons-compress:1.27.1")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
}
