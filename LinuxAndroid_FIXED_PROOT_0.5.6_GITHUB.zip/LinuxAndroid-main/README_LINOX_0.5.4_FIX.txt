LinOx 0.5.4 — fixed ARM64 PRoot + distro activation

What was fixed:
1. The distro installer stored rootfs files under:
   <externalFilesDir>/linox/distros/<distro>/rootfs
   but LinuxRuntime searched only:
   <filesDir>/linox-runtime/rootfs
   This caused the screenshot error even when PRoot was bundled.

2. LinuxRuntime now activates the exact distro selected in DistroManager.

3. External app-private storage is accepted as a safe rootfs location.

4. The terminal now verifies/activates the selected distro before starting PRoot.

5. RUN and the keyboard action both send commands to the live Linux shell.

6. Rootfs installation now checks for a real /bin/sh or /usr/bin/sh before
   reporting a distro as installed.

The APK still runs rootless: Android's kernel is used, with the bundled
AArch64 PRoot binary providing the Linux userspace view.
