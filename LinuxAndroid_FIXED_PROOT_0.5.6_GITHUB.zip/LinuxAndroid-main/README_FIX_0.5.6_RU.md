# LinOx 0.5.6 — исправление PRoot на Android

Исправлена проблема, при которой запуск Alpine показывал:

- `proot error: can't create temporary directory: Permission denied`
- `proot error: can't create glue rootfs`
- `proot error: '/bin/sh' is not executable`

## Что изменено

1. **RootFS больше не хранится в external/shared storage.**
   Дистрибутивы теперь устанавливаются в приватное `filesDir` приложения. На некоторых Android внешнее хранилище может быть смонтировано с `noexec`, из-за чего PRoot не может выполнить `/bin/sh`.

2. **PROOT_TMP_DIR задан явно.**
   PRoot получает отдельную временную директорию внутри приватного хранилища приложения с правами на запись. Это устраняет ошибку `can't create temporary directory`.

3. **Уменьшен набор Android bind-монтирований.**
   `/sys` и `/system/bin` больше не монтируются при старте shell. Оставлены только `/dev` и `/proc`, если они доступны.

4. **`/bin/sh` нормализуется.**
   Если Alpine/Debian предоставляет shell через symlink (`/bin/sh -> busybox`, `dash` и т.п.), LinOx материализует критический shell как обычный executable-файл. Это предотвращает ошибку `'/bin/sh' is not executable` на Android-файловых системах.

5. **Миграция старого rootfs.**
   Если у старой версии уже есть дистрибутив в `externalFilesDir`, новая версия автоматически копирует его в приватное хранилище при запуске.

6. **GitHub Actions** уже настроен на сборку debug APK.

## После установки APK

Рекомендуется полностью удалить старый LinOx перед установкой новой версии, если старые данные не нужны. Затем:

1. открыть LinOx;
2. выбрать **Alpine Linux 3.24**;
3. нажать **PREPARE / DOWNLOAD**;
4. дождаться `RootFS verified and installed`;
5. нажать **START LINUX**;
6. проверить:

```sh
uname -m
cat /etc/os-release
ls -l /bin/sh
printf 'hello\\n'
```

Ожидаемая архитектура: `aarch64`.

## Сборка через GitHub

Workflow находится в `.github/workflows/build.yml`.

Он запускается:

- кнопкой **Actions → Build LinOx APK → Run workflow**;
- автоматически после push в `main`.

Готовый APK находится в **Artifacts → LinOx-0.5.6-APK**.
