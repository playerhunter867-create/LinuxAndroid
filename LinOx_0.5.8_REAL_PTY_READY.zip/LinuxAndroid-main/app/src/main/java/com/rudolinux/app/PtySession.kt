package org.linox.mobile

import android.os.ParcelFileDescriptor
import java.io.InputStream
import java.io.OutputStream
import java.nio.charset.Charset
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Interactive terminal session backed by a real Unix PTY.
 *
 * PRoot and Alpine's BusyBox ash see an actual controlling terminal instead of
 * ProcessBuilder pipes, so job control and interactive shell startup work as
 * they do in a normal Linux terminal.
 */
class PtySession private constructor(
    private val handle: Long,
    private val pfd: ParcelFileDescriptor,
    private val input: InputStream,
    private val output: OutputStream
) {
    private val stopped = AtomicBoolean(false)

    companion object {
        fun start(
            executable: String,
            args: List<String>,
            environment: Map<String, String> = emptyMap(),
            workingDirectory: String? = null
        ): PtySession {
            val env = environment.entries.map { (key, value) -> "$key=$value" }.toTypedArray()
            val handle = NativePty.nativeStart(
                executable,
                args.toTypedArray(),
                env,
                workingDirectory
            )

            if (handle <= 0) {
                error("Unable to create Linux PTY for PRoot")
            }

            val fd = NativePty.nativeFd(handle)
            if (fd < 0) {
                NativePty.nativeStop(handle)
                error("Linux PTY returned an invalid file descriptor")
            }

            val pfd = ParcelFileDescriptor.adoptFd(fd)
            // Duplicate the master FD so closing the Java input/output streams
            // cannot accidentally double-close the descriptor owned by pfd.
            val inputPfd = ParcelFileDescriptor.dup(pfd.fileDescriptor)
            val outputPfd = ParcelFileDescriptor.dup(pfd.fileDescriptor)
            val input = ParcelFileDescriptor.AutoCloseInputStream(inputPfd)
            val output = ParcelFileDescriptor.AutoCloseOutputStream(outputPfd)
            return PtySession(handle, pfd, input, output)
        }
    }

    fun send(command: String) {
        if (stopped.get() || !isAlive()) return
        try {
            output.write(command.toByteArray(Charsets.UTF_8))
            output.write('\n'.code)
            output.flush()
        } catch (_: Exception) {
            // The shell may have exited between isAlive() and the write.
        }
    }

    fun sendBytes(bytes: ByteArray) {
        if (stopped.get() || !isAlive()) return
        runCatching {
            output.write(bytes)
            output.flush()
        }
    }

    fun readLoop(
        onText: (String) -> Unit,
        onExit: (Int) -> Unit = {}
    ) {
        Thread {
            var exitCode = -1
            try {
                val buffer = ByteArray(8192)
                while (!stopped.get()) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    if (count > 0) {
                        onText(String(buffer, 0, count, Charset.forName("UTF-8")))
                    }
                }
            } catch (e: Exception) {
                if (!stopped.get()) {
                    onText("\n[LinOx] ${e.message ?: e.javaClass.simpleName}\n")
                }
            } finally {
                if (!NativePty.nativeIsAlive(handle)) exitCode = 0
                onExit(exitCode)
            }
        }.apply {
            name = "LinOx-pty-reader"
            isDaemon = true
            start()
        }
    }

    fun resize(rows: Int, columns: Int) {
        if (!stopped.get()) NativePty.nativeResize(handle, rows, columns)
    }

    fun stop() {
        if (!stopped.compareAndSet(false, true)) return
        runCatching { input.close() }
        runCatching { output.close() }
        runCatching { pfd.close() }
        NativePty.nativeStop(handle)
    }

    fun isAlive(): Boolean = !stopped.get() && NativePty.nativeIsAlive(handle)
}
