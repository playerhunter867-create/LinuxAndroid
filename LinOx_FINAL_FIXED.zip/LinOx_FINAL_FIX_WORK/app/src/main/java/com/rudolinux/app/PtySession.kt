package org.linox.mobile

import java.io.File
import java.io.OutputStream
import java.io.OutputStreamWriter
import java.nio.charset.StandardCharsets
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Persistent interactive shell transport.
 *
 * This is intentionally a single long-lived ProcessBuilder session.  Commands
 * are serialized through one writer so a fast second Enter cannot race the
 * first write or close the stream. stdout/stderr are consumed continuously by
 * one reader thread.
 */
class PtySession private constructor(
    private val process: Process,
    output: OutputStream
) {
    private val stopped = AtomicBoolean(false)
    private val writer = OutputStreamWriter(output, StandardCharsets.UTF_8)
    private val writeLock = Any()
    private val sender = Executors.newSingleThreadExecutor { runnable ->
        Thread(runnable, "LinOx-command-writer").apply { isDaemon = true }
    }

    companion object {
        fun start(
            executable: String,
            args: List<String>,
            environment: Map<String, String> = emptyMap(),
            workingDirectory: String? = null
        ): PtySession {
            val command = ArrayList<String>(args.size + 1)
            command.add(executable)
            command.addAll(args)

            val builder = ProcessBuilder(command).redirectErrorStream(true)
            if (workingDirectory != null) {
                val dir = File(workingDirectory)
                if (dir.isDirectory) builder.directory(dir)
            }
            builder.environment().putAll(environment)

            val process = builder.start()
            return PtySession(process, process.outputStream)
        }
    }

    fun send(command: String) {
        if (stopped.get() || !process.isAlive) return
        val line = command.trimEnd('\r', '\n')
        if (line.isEmpty()) return

        sender.execute {
            if (stopped.get() || !process.isAlive) return@execute
            try {
                synchronized(writeLock) {
                    writer.write(line)
                    writer.write("\n")
                    writer.flush()
                }
            } catch (_: Exception) {
                // The shell may exit between the liveness check and write.
            }
        }
    }

    fun readLoop(onText: (String) -> Unit, onExit: (Int) -> Unit = {}) {
        Thread({
            var exitCode = -1
            try {
                process.inputStream.bufferedReader(StandardCharsets.UTF_8).use { reader ->
                    val buffer = CharArray(8192)
                    while (!stopped.get()) {
                        val count = reader.read(buffer)
                        if (count < 0) break
                        if (count > 0) onText(String(buffer, 0, count))
                    }
                }
                exitCode = process.waitFor()
            } catch (e: Exception) {
                if (!stopped.get()) onText("\n[LinOx] ${e.message ?: e.javaClass.simpleName}\n")
            } finally {
                onExit(exitCode)
            }
        }, "LinOx-shell-reader").apply {
            isDaemon = true
            start()
        }
    }

    fun stop() {
        if (!stopped.compareAndSet(false, true)) return
        runCatching { synchronized(writeLock) { writer.close() } }
        sender.shutdownNow()
        if (process.isAlive) {
            process.destroy()
            try {
                if (!process.waitFor(700, TimeUnit.MILLISECONDS)) process.destroyForcibly()
            } catch (_: InterruptedException) {
                process.destroyForcibly()
                Thread.currentThread().interrupt()
            }
        }
    }

    fun isAlive(): Boolean = process.isAlive && !stopped.get()
}
