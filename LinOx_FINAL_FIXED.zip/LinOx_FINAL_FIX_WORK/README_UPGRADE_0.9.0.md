# LinOx 0.9.0 Upgrade

Upgrade based on the LinOx 0.5.8 SHELL_FIXED project.

## Main changes
- Persistent shell transport with serialized command writes.
- UTF-8 continuous stdout/stderr reader.
- Duplicate Enter debounce and command history (D-pad up/down).
- Safer terminal lifecycle and cleanup.
- Alpine setup command: `linox alpine`.
- Alpine installs bash, curl, wget, git, nano, Python 3/pip, build-base, cmake, pkgconf and OpenSSH client.
- Expanded `linox doctor` checks.
- Version bumped to 0.9.0 / versionCode 20.
- GitHub Actions uses Gradle 8.10.2 and verifies the ARM64 PRoot APK.

## Alpine
After installing Alpine, open the terminal and run:

```sh
linox alpine
```

The command is intentionally manual so the first boot stays fast and does not unexpectedly consume network/data.

## Build
GitHub Actions: **Build LinOx 0.9.0 Debug APK**.
