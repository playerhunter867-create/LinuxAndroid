# LinOx 0.9.0 — Upgrade Changelog

Base: LinOx 0.5.8 SHELL_FIXED.

## Terminal
- Persistent shell session is kept alive between commands.
- Command writes are serialized through one writer thread.
- UTF-8 output is continuously consumed from the process.
- Enter is debounced to prevent accidental duplicate submissions.
- Up/down command history is available from the input field.
- Terminal lifecycle closes the writer, executor and process cleanly.
- Added PS1/PS2 so the shell visibly confirms that it is ready for the next command.

## Alpine
- Added `linox alpine` setup command.
- Uses `apk`, never `apt`, for Alpine.
- Installs bash, curl, wget, git, nano, ca-certificates, Python 3/pip.
- Adds build-base, cmake, pkgconf and openssh-client.
- Expanded `linox doctor` with curl/wget/nano/apk/apt checks.
- Setup is manual so first boot remains fast.

## Build
- Version: 0.9.0 / versionCode 20.
- Android Gradle Plugin: 8.7.3.
- GitHub Actions Gradle: 8.10.2.
- Debug APK workflow verifies the bundled AArch64 PRoot.
