# LinOx build fix

This package fixes the Gradle mismatch where GitHub Actions runs Gradle 8.7 while Android Gradle Plugin requires at least 8.9.

The included workflow installs **Gradle 8.10.2** and explicitly runs that executable from the repository root. It does not build from `_build`.

## Important
Replace the old repository contents with this package rather than merging it into a repository that still contains an old workflow. The error path `/LinuxAndroid/_build/` proves that an older workflow is still being executed if that path appears in the build log.

After uploading, use the workflow:
`LinOx - Build Debug APK`

The first verification step must print:
`Gradle 8.10.2`
