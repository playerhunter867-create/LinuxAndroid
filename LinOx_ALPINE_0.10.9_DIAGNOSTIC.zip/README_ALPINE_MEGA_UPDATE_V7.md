# LinOx Alpine Mega Update v0.10.0

Alpine Linux 3.24 is the focus of this release.

## Alpine improvements
- Persistent `/bin/sh` shell remains pipe-safe; no unsupported `--sysvipc` option.
- PRoot exposes `/proc` and `/dev` for `ps`, `/dev/null`, `/dev/urandom`, TLS and common CLI programs.
- Alpine repositories are pinned to the matching official 3.24 `main` and `community` repositories.
- `apk update` retries three times and reports a useful error instead of silently failing.
- One-click **TOOLS** button installs the development environment.
- `linox alpine` installs Python 3, pip, virtualenv, Nano, Vim, Git, curl, wget, certificates, build tools and common utilities.
- `python`, `pip` and `py` command shims are available after setup.
- `nano file.py` opens LinOx's Android-backed editor when the guest has no real controlling TTY. Files created in `/root` are persistent and can be executed with `python3 file.py`.
- Guest-path validation prevents editor access outside the Linux storage.

## Example

```sh
linox alpine
python3 --version
python --version
nano hello.py
python3 hello.py
apk --version
ps
curl --version
```

The terminal transport is still not a kernel PTY. The built-in `nano` command is therefore handled by the Android editor so normal `nano file.py` workflows remain usable without pretending a pipe is a real TTY.


LinOx 0.10.3 stability patch: Alpine PRoot no longer binds the entire Android /dev tree; only required device nodes are bound.
