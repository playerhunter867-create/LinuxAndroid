# LinOx 0.10.9 — Persistent Shell Diagnostic

## Goal
This build does **not** replace PRoot. It isolates the remaining failure between the known-good one-shot PRoot probes and the Android persistent stdin transport.

## What changed
- PRoot binary remains unchanged.
- Alpine still launches `/bin/sh` without `-i`.
- Existing isolated PRoot probes remain.
- Added `persistent-sequence` probe using the same `--kill-on-exit -0 -r <rootfs> -w /root /bin/sh` launch path as the real session.
- The probe executes `pwd`, `ls`, and explicit markers before/after `ls`.
- The diagnostic reports `PERSISTENT_SEQUENCE=PASS` or `PERSISTENT_SEQUENCE=FAIL`.
- Version bumped to 0.10.9.

## Interpretation
### If `PERSISTENT_SEQUENCE=FAIL`
Do **not** replace PRoot yet. The failure is reproducible without the Android terminal UI, so we inspect the PRoot/rootfs launch path next.

### If `PERSISTENT_SEQUENCE=PASS` but the real shell still exits with 255
PRoot and Alpine can execute the same command sequence. The remaining suspect is the Android persistent stdin/reader transport. The next fix should target `PtySession`, not the PRoot binary.

PRoot documents that a non-zero exit can indicate an internal PRoot error or the exit status of the last guest process, so the emitted output is important when deciding which component failed.
