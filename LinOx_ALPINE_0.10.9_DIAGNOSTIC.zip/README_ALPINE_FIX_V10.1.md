# LinOx 0.10.4 — Alpine stability fix

This build keeps the existing Alpine 3.24 rootfs and PRoot architecture, but hardens Alpine command execution on Android.

## Fixes

- Materializes executable BusyBox applet symlinks under `/bin`, `/sbin`, `/usr/bin` and `/usr/sbin` so commands such as `cat`, `ls`, `grep` and similar tools do not depend on fragile symlink translation on Android storage.
- Removes the unsupported PRoot `-L` option; this fixes the `unknown option '-L'` crash on the bundled PRoot.
- Keeps `PROOT_NO_SECCOMP=1` for Android kernels where PRoot seccomp interception is unreliable.
- Keeps the persistent shell transport and automatic stdout/stderr draining.
- Keeps Gradle 8.10.2 / Java 17 GitHub Actions build configuration.

## First device test

After installing the new APK, open Alpine and run: `echo hello`, `cat /etc/alpine-release`, `ls /bin`, `pwd`, then `apk --version`.

The expected result is that the shell remains alive after each command.
