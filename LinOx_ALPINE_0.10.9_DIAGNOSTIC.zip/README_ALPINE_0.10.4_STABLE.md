# LinOx Alpine 0.10.5 — stability fix

This build is focused on Alpine runtime stability on modern Android.

Changes:
- removed the unnecessary PRoot `--link2symlink` option;
- removed host `/proc` and `/dev` binds from the Alpine PRoot baseline;
- kept PRoot seccomp disabled for Android compatibility;
- kept rootfs, HOME and TMP binds in app-private storage;
- kept target SDK 28 required by this rootless PRoot design;
- bumped LinOx version to 0.10.5.

The ZIP contains the existing bundled PRoot binary; it does not silently replace it
with an unverified third-party binary. If Alpine still exits with code 255 after
this build, the next step is to replace/test the bundled PRoot implementation
itself rather than changing random Alpine shell options.


## 0.10.5 stability fix

- Alpine keeps its own persistent `/root` and `/tmp` instead of binding Android app storage there.
- Removed automatic BusyBox applet materialization; Alpine's native symlink layout is preserved.
- Added `PROOT_DONT_POLLUTE_ROOTFS=1`.
- This specifically targets the observed PRoot exit code 255 when running ordinary commands such as `ls` from `/root`.


## 0.10.7 diagnostic rollback
0.10.7 rolls back the 0.10.6 Alpine cwd experiment and adds isolated PRoot startup diagnostics.
