# LinOx 0.10.8 — PRO FIX

## Goal
This build keeps the successful PRoot diagnostics from 0.10.7 but rolls back the host-working-directory change that affected the persistent Alpine shell.

## Runtime changes
- Alpine remains `/bin/sh` without `-i`.
- PRoot still uses `-w /root`.
- The Android-side `home` directory is **not** passed as the host `ProcessBuilder` cwd. The host cwd is left unset so PRoot controls the guest cwd.
- One-shot Linux command execution again uses the runtime directory as its host cwd and explicitly enters `/root` inside the guest.
- `PROOT_NO_SECCOMP=1` remains enabled.
- The bundled PRoot binary is unchanged in this build.

## Diagnostics
0.10.7 already demonstrated that the bundled PRoot can successfully run `/bin/sh`, `pwd`, `ls /`, and read `/etc/alpine-release` in isolated probes. This build preserves those probes and changes only the persistent-session integration path.

## What to test on the phone
1. Start Alpine.
2. Wait until `PRoot probes passed` appears.
3. Run `echo hello`.
4. Run `pwd`.
5. Run `ls`.
6. Run `cat /etc/alpine-release`.
7. Run `python3 --version` only after installing Python through the Alpine tools button/command.

If `ls` still kills the session, the next step is a controlled PRoot-binary A/B test rather than changing multiple runtime variables at once. Upstream PRoot 5.4.0 specifically lists an Android cwd compatibility fix, so it is a sensible candidate for that isolated test.
