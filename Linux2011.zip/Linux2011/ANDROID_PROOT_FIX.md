# Android PRoot fix

The previous implementation executed a copied PRoot binary from writable
`filesDir`. Modern Android versions can deny `execve()` from writable
app-data directories. This build packages the AArch64 PRoot binary as
`app/src/main/jniLibs/arm64-v8a/libproot.so` and executes it from
`ApplicationInfo.nativeLibraryDir`.

The runtime also validates the binary at startup and shows a specific error
if Android did not extract it.

The Linux rootfs location remains compatible with the existing installed
Alpine data, so reinstalling the APK should not require downloading Alpine
again.

References:
- https://developer.android.com/ndk/guides/abis
- https://u1f383.github.io/android/2025/06/15/run-native-binary-on-android.html
